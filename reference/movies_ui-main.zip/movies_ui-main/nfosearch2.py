#!/usr/bin/env python3
"""Run-local Kodi NFO index for the Movies UI.

The media library is authoritative.  This module deliberately has no on-disk
database: :func:`rebuild_index` creates a complete replacement index in RAM.
"""
import base64
import io
import json
import mimetypes
import os
from pathlib import Path
import xml.etree.ElementTree as et
from collections import defaultdict

DIRS = ["/mnt/2tb/Movie"]
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".avi", ".m4v", ".webm", ".mov"}
db = {}


def build_index(dirs=None):
    """Parse all movie NFOs and return a complete, not-yet-installed index."""
    records = []
    by_title = {}
    by_actor = defaultdict(set)
    by_genre = defaultdict(set)
    all_actors = {}
    all_genres = {}
    lost_found = []
    for directory in list(dirs or DIRS):
        root = Path(directory)
        try: folders = sorted((p for p in root.iterdir() if p.is_dir() and not p.name.startswith(".")), key=lambda p: p.name.casefold())
        except OSError: folders = []
        for folder in folders:
            video = _first_video(folder)
            path, xml = _parsed_movie_nfo(folder)
            if path is None:
                if video:
                    lost_found.append(_lost_found_record(folder, video))
                continue
            title = (xml.findtext("title") or path.stem).strip()
            record = {
                    "title": title, "folder": str(path.parent.resolve()),
                    "nfo": str(path.resolve()), "plot": xml.findtext("plot") or "",
                    "genres": [x.text.strip() for x in xml.findall("genre") if x.text and x.text.strip()],
                    "actors": [x.text.strip() for x in xml.findall(".//actor/name") if x.text and x.text.strip()],
                    "metadata": _human_metadata(xml),
                }
            records.append(record)
            by_title[record["title"].casefold()] = record
            for actor in record["actors"]:
                key = actor.casefold()
                all_actors.setdefault(key, actor)
                by_actor[key].add(record["title"])
            for genre in record["genres"]:
                key = genre.casefold()
                all_genres.setdefault(key, genre)
                by_genre[key].add(record["title"])
    replacement = {
        "records": records, "by_title": by_title,
        "all_actors": sorted(all_actors.values(), key=str.casefold),
        "movies_by_actor": {key: sorted(titles, key=str.casefold) for key, titles in by_actor.items()},
        "all_genres": sorted(all_genres.values(), key=str.casefold),
        "by_genre": {genre: sorted(titles, key=str.casefold) for genre, titles in by_genre.items()},
        "lost_found": lost_found,
        "lost_found_by_id": {record["id"].casefold(): record for record in lost_found},
    }
    return replacement


def _human_metadata(xml):
    """Return searchable, human-readable NFO fields (never serialized XML)."""
    values = []
    for tag in ("plot", "outline", "tagline", "director", "studio", "country"):
        values.extend(text.strip() for text in (node.text for node in xml.findall(tag))
                      if text and text.strip())
    return " ".join(values)


def _lost_found_record(folder, video):
    return {"id": folder.name, "name": folder.name, "media": Path(video).name,
            "folder": str(folder.resolve()), "video": video}


def nfo_for_folder(folder):
    """Return the first usable movie NFO in deterministic filename order."""
    return _parsed_movie_nfo(folder)[0]


def _parsed_movie_nfo(folder):
    """Return the authoritative usable movie NFO and its parsed root."""
    try:
        candidates = sorted((p for p in Path(folder).iterdir()
                             if p.is_file() and p.suffix.casefold() == ".nfo"),
                            key=lambda p: (p.name.casefold(), p.name))
    except OSError:
        return None, None
    for candidate in candidates:
        try:
            xml = et.parse(candidate).getroot()
        except (OSError, et.ParseError):
            continue
        return candidate, xml
    return None, None


def poster_for_folder(folder):
    """Resolve the authoritative poster using the shared deterministic rule."""
    folder = Path(folder)
    for name in ("poster.jpg", "poster.jpeg", "poster.png", "poster.webp"):
        candidate = folder / name
        if candidate.is_file():
            return candidate
    try:
        candidates = sorted((p for p in folder.iterdir() if p.is_file()
                             and p.suffix.casefold() in IMAGE_EXTENSIONS
                             and "poster" in p.name.casefold()), key=lambda p: p.name.casefold())
    except OSError:
        return None
    return candidates[0] if candidates else None


def rebuild_index(dirs=None):
    """Build and atomically install a complete runtime index."""
    replacement = build_index(dirs)
    global db
    db = replacement
    return db


def _record(title): return db.get("by_title", {}).get(title.casefold())
def listByGenre(genre, dirs): return list(db.get("by_genre", {}).get(genre.casefold(), []))
def listAllGenres(dirs): return list(db.get("all_genres", []))
def findActors(dirs): return list(db.get("all_actors", []))
def findMoviesByActor(actor, dirs):
    result = db.get("movies_by_actor", {}).get(actor.casefold(), [])
    return json.dumps(result) if result else None


def _first_video(folder):
    try: items = sorted(Path(folder).iterdir(), key=lambda p: p.name.casefold())
    except OSError: return None
    for item in items:
        if item.is_file() and item.suffix.lower() in VIDEO_EXTENSIONS and "trailer" not in item.name.lower():
            return str(item.resolve())
    return None


def findMovieFileByTitle(dirs, title):
    record = _record(title)
    return _first_video(record["folder"]) if record else None


def findLostFoundMovie(identity):
    """Resolve only an identity enumerated by the current trusted index."""
    record = db.get("lost_found_by_id", {}).get(identity.casefold())
    if not record:
        return None
    # Re-resolve with the shared selection rule rather than trusting stale/client paths.
    return _first_video(record["folder"])


def findActorsForOneMovie(dirs, movie):
    record = _record(movie)
    return json.dumps(record["actors"] if record else [])


def image_file_to_data_url(path, max_size=(400, 400), quality=85):
    from PIL import Image
    with Image.open(path) as image:
        image.thumbnail(max_size)
        if image.mode not in ("RGB", "L"): image = image.convert("RGB")
        output = io.BytesIO(); image.save(output, "JPEG", quality=quality, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(output.getvalue()).decode("ascii")


def actor_image_path(actor):
    needle = actor.replace(" ", "_").casefold()
    for directory in DIRS:
        actor_dir = Path(directory) / ".actors"
        try: files = sorted(actor_dir.iterdir(), key=lambda p: p.name.casefold())
        except OSError: continue
        for path in files:
            if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS and needle in path.name.casefold():
                return str(path.resolve())
    return None


def findActorImage(actor):
    path = actor_image_path(actor)
    return image_file_to_data_url(path) if path else None


def findPosterByTitle(title, dirs):
    record = _record(title)
    if not record: return None
    poster = poster_for_folder(record["folder"])
    return image_file_to_data_url(str(poster)) if poster else None


def findPlotByTitle(dirs, title):
    record = _record(title)
    return "'''%s'''" % (record["plot"] if record else "")


if __name__ == "__main__":
    rebuild_index()
