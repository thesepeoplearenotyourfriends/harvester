# Movies UI

**The first fully functioning Severin desktop application.**

Movies UI is a complete, local-first Movies **and TV** library browser built on
the Severin desktop runtime. It is both a real application and the first practical
boilerplate/skeleton/example for building future Severin-runtime desktop apps.

This repository is intentionally more precedent than framework. It demonstrates
the small set of boundaries a Severin app actually needs—package assets, a
semantic JavaScript/Python bridge, disposable cache data, trusted native
capabilities, and a headed application lifecycle—without adding an HTTP server,
frontend framework, npm build, or general-purpose RPC layer.

> **Status:** the former Movies UI and TV UI are now one working Severin app.
> The Movies/TV switch changes the active backend and cache namespace while the
> same document, interaction model, search, details, cast, artwork, and playback
> flows remain in place. The older WebKit host is retained under `webkit/` as an
> alternate/reference implementation, not as the primary architecture.

## What this example establishes

The application has five deliberately distinct layers:

```text
external movie and TV libraries        authoritative user data
                 |
                 | trusted Python-only access
                 v
movies-ui.py                          host, policy, native capabilities
          |                    |
          | Severin bridge     | best-effort derived writes
          v                    v
index.html                  .cache/
          ^                    |
          |     asset://       |
          +--------------------+
```

* **The package** contains the HTML, CSS, and other resources shipped with the
  app.
* **JavaScript RAM** holds cheap, frequently queried per-run state such as the
  combined title/actor search index and genre maps.
* **`.cache/`** contains only reconstructible working data written by Python and
  readable by the page as package assets.
* **The bridge** carries semantic capability requests and small JSON results.
* **Python** is the trusted adapter to NFO metadata, files outside the package,
  and native playback.

The governing design rule is **duplicate storage, singular authority**. Cached
posters, actor images, plots, and indexes can be duplicated for speed; the media
library remains the only source of truth.

## Repository tour

```text
movies_ui/
├── index.html              Severin document, UI behavior, and run-local state
├── css/my.css              application-owned styles (no Bootstrap runtime)
├── movies-ui.py            Severin host, bridge actions, cache, and launcher
├── tv_nfosearch2.py        in-repo TV NFO metadata/index adapter
├── movies-ui.desktop       example desktop entry
├── .cache/                 generated at runtime; disposable and gitignored
├── webkit/                 retained combined Movies WebKit implementation
└── reference/              historical TV/WebKit reference implementation
```

There is no Flask service, localhost port, CDN, npm dependency tree, or frontend
build step. The active UI is plain HTML/CSS/JavaScript, and `movies-ui.py` is the
application controller.

## Running the application

This example expects Linux, Python 3, an installed/importable Severin Python
package, access to the media libraries, and the NFO helper used by the Movies
backend. Playback uses a configured native command.

1. Edit the user-configurable constants near the top of `movies-ui.py`:

   ```python
   MOVIES_LIBRARY_DIR = "/mnt/2tb/Movie"
   TV_LIBRARY_DIR = "/mnt/2tb/TV"
   MOVIES_HELPER_PATH = "/path/to/nfosearch2.py"
   PLAYER_COMMAND = "vlcshortcut"
   OPERATOR_ACCOUNT = "operator"
   ```

   The TV metadata implementation is included as `tv_nfosearch2.py`; the Movies
   implementation is loaded from `MOVIES_HELPER_PATH` to preserve the existing
   production library integration.

2. Launch the host:

   ```sh
   python3 movies-ui.py
   ```

3. Optionally adapt `movies-ui.desktop` to the repository's installed path.

The configured window is `800 × 400`. `app.load_path(index.html)` installs the
document, and `app.run()` owns the headed event loop until the window closes.
If launched as root, this particular application creates safe cache directories
and drops to `OPERATOR_ACCOUNT` **before** importing Severin or either metadata
backend. That privilege policy belongs to this app, not to every Severin app;
adapt it rather than copying it blindly.

## The minimal Severin host

The essential host shape is small:

```python
import severin

app_box = {}
bridge = make_bridge_callback(app_box)
app = severin.App(
    width=800,
    height=400,
    bridge=bridge,
    package_id="com.moviesui.app",
)
app_box["app"] = app
app.load_path("/absolute/path/to/index.html")
app.run()
app.close()
```

Three details matter:

1. **`package_id` is functional identity.** It defines which contained package
   resources the document can address through `asset://`.
2. **The bridge is installed when the app is constructed.** The page receives
   Severin's `globalThis.severin.send(...)` API; the host receives a callback.
3. **`run()` owns the GUI lifecycle.** The application does not implement a
   secondary pump or queue-drain loop.

## Severin ↔ Python bridge

### Page-to-host requests

The page sends a JSON-compatible message through the injected Severin API:

```js
const response = await globalThis.severin.send({
  id: 17,
  action: "movies.get_poster",
  data: {title: "Alien"}
});
```

Movies UI wraps this in `App.request(action, data)`. The wrapper adds the active
world (`movies.` or `tv.`), increments the request ID, validates the response,
and discards a result if the user switched worlds while it was in flight.

Frames have one intentionally boring shape:

```json
{"id":17,"action":"movies.get_poster","data":{"title":"Alien"}}
```

Replies preserve the ID and use either:

```json
{"id":17,"ok":true,"result":{"title":"Alien","available":true}}
```

or:

```json
{"id":17,"ok":false,"error":"explanation"}
```

### Host callback and deferred replies

Severin calls the Python bridge with an opaque **receipt** and the JSON text. A
fast operation may return a reply directly. Movies UI instead demonstrates the
deferred form required by real filesystem work:

```text
JavaScript severin.send(message)
             |
             v
bridge(receipt, json_text)
  ├── starts a worker thread
  └── returns None, retaining the receipt
             |
             v
worker validates and dispatches an explicit action
             |
             v
app.write(receipt, reply_json)
             |
             v
the original JavaScript Promise resolves
```

The callback must return quickly because Severin owns the window and event loop.
Returning `None` is deliberate: it keeps the receipt alive until the worker
finishes. The worker calls `app.write(receipt, ...)` exactly for that pending
request. No application code guesses at routing from the request ID, and no
synchronous filesystem work blocks the GUI callback.

### Capabilities, not remote Python

`BRIDGE_ACTIONS` is an explicit allowlist. The current application exposes the
same semantic surface for each world:

```text
{movies,tv}.ensure_library_index_cache
{movies,tv}.get_plot
{movies,tv}.get_poster
{movies,tv}.get_cast
{movies,tv}.get_actor_index
{movies,tv}.get_actor_image
{movies,tv}.get_titles_for_actor
{movies,tv}.play
```

There is also `__ping__` for bridge diagnostics. There is intentionally no
`readFile(path)`, `writeFile(path)`, `shell(command)`, Python `eval`, generic
method invocation, or frontend-selected executable. A future app should copy
the *allowlisted semantic-action pattern*, then define capabilities appropriate
to its own domain.

The bridge is a command wire, not a data hose. Small results belong there; the
bulk presentation index is atomically published as each world's disposable
`.cache/<world>/library-index.json`. Package resources and cache hits do not
need a bridge round trip.

## `asset://`: package-local reads

Severin gives a loaded package a contained resource namespace:

```text
asset://<package-id>/<package-relative-path>
```

For this app:

```text
package_id                         com.moviesui.app
package root                       asset://com.moviesui.app/
Movies cache manifest              asset://com.moviesui.app/.cache/movies/manifest.json
TV actor index                     asset://com.moviesui.app/.cache/tv/actor-index.json
```

The package ID in `movies-ui.py` and `index.html` must agree. It is not branding
or display text: it connects the host's package boundary to the document's asset
namespace. Ordinary package-relative resources such as `css/my.css` remain
simple relative document URLs; explicit `asset://` URLs are useful when code
needs a stable package-root address.

`asset://` is **not** an alias for the machine's filesystem. The page can ask for
contained package-relative resources, not arbitrary `/mnt/...` paths. External
library access remains a Python capability. This separation lets the renderer
load ordinary resources directly without granting it the backend's filesystem
authority.

## `.cache/`: writable by Python, readable as assets

The conventional cache root is inside the package directory:

```text
.cache/
├── movies/
│   ├── manifest.json
│   ├── actor-index.json
│   ├── posters/<sha256>.<ext>
│   └── actors/<sha256>.<ext>
└── tv/
    ├── manifest.json
    ├── actor-index.json
    ├── tv_search_results.db
    ├── posters/<sha256>.<ext>
    └── actors/<sha256>.<ext>
```

Python owns writes and uses atomic replacement where practical. Names become
SHA-256 cache keys rather than filenames supplied by the document. The page can
then fetch a known derived entry directly through the package namespace:

```js
fetch('asset://com.moviesui.app/.cache/movies/manifest.json', {
  cache: 'no-store'
});
```

The manifest maps semantic title/actor names to package-relative derived files.
On an image hit, the page assigns that `asset://` URI directly to `<img src>`.
On a miss, it requests the semantic image capability from Python. Python returns
an immediately usable data URL and warms the package cache in a background
thread for later requests. Image bytes do not require a second request/receipt
protocol, and the frontend never learns the authoritative source path.

### Cache contract

`.cache/` is always:

* **derived** — it contains no authoritative or irreplaceable user data;
* **reconstructible** — the trusted backend can produce entries again;
* **optional** — failure to read or write it cannot make a cold request fail;
* **versioned and validated** — malformed or incompatible JSON is a miss;
* **best effort** — cache warming happens after or alongside a successful
  authoritative response; and
* **disposable** — this must be safe at any time:

  ```sh
  rm -rf .cache/
  ```

Startup first attempts the cached index while Python initializes the backend and
atomically publishes a replacement. Background maintenance then signals the
page to load that file, so a missing, damaged, or stale cache is repaired without
sending the index through a bridge frame. Do not place preferences, documents,
annotations, or other durable application state in this directory.

Not every future Severin app needs `.cache/`. The reusable concept is a narrow
package-local scratch area with explicit ownership and deletion semantics—not a
mandatory persistence API.

## Movies and TV integration

The merged application shares one frontend but does **not** blur the two data
models together:

* `activeWorld` namespaces every bridge action and package-cache lookup.
* Movies and TV keep separate manifests, actor indexes, locks, NFO adapters, and
  playback lookup rules.
* Switching worlds increments a UI generation counter. Late async responses
  from the previous world are ignored rather than painting stale state.
* Per-world in-memory state can be retained without making it durable state.
* Search combines titles and actors for the currently active world, with typed
  results leading to the existing details/filmography flows.

This is a useful skeleton pattern: share presentation and interaction where the
product calls for it, while keeping backend authority and cache namespaces
explicit.

## Security and authority model

Severin's renderer is the front panel; Python is the authority layer.

```text
Renderer may:
  render and manipulate the DOM
  keep ephemeral state in RAM
  read contained package resources through asset://
  request named capabilities through the bridge

Python may:
  inspect configured external libraries
  parse and index NFO metadata
  write disposable package cache entries
  launch the configured media player
  accept or reject every semantic action
```

The Severin document runtime has no application-provided HTTP/localhost path and
does not receive generic file or process primitives. This is a capability
boundary, not a claim that the example is a complete OS sandbox. In particular,
the app-specific privilege drop, path validation, package containment, and
allowlisted bridge should remain visible and reviewable rather than being hidden
behind a prematurely general security framework.

## Using this repository as a Severin app skeleton

For a new application, preserve the boundaries and replace the domain:

1. Choose a stable reverse-domain package ID and use the same value in the host
   and document.
2. Keep the initial document and static assets package-local.
3. Construct `severin.App`, install a bridge, call `load_path()`, and let
   `run()` own the headed lifecycle.
4. Put cheap, run-local indexes in JavaScript memory rather than persisting them
   by reflex.
5. Define a small action table of semantic capabilities. Validate message shape
   and every action's data before touching trusted resources.
6. Defer expensive actions and resolve their opaque receipts with `app.write()`.
7. Use `asset://<package-id>/...` for contained resources that the page can read
   without Python mediation.
8. If caching is useful, make `.cache/` derived, versioned, best effort, and safe
   to delete. Keep durable state elsewhere with a separate contract.
9. Keep native/system effects in Python and expose only the narrow operation the
   UI actually needs.
10. Add abstractions only after multiple applications prove the same convention.

Avoid copying app-specific assumptions such as the NFO schema, `operator`
account, VLC wrapper, media-library paths, or cache manifest shape into a generic
template. They demonstrate where application policy belongs; they are not
Severin runtime requirements.

## Why this stays deliberately small

Movies UI does not attempt to define a universal cache framework, database,
permission manifest, persistent-state API, app generator, or generalized RPC
system. The first complete application is evidence for a few useful conventions,
not evidence that every policy should be standardized immediately.

As more real Severin applications repeat these patterns, the stable pieces can
move into a dedicated template or factory. Until then, this repository is the
working reference: a full desktop app first, and boilerplate grounded in that
experience second.
