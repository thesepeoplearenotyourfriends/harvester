#!/usr/bin/python3

## This version keeps the native WebKit bridge/resource plumbing while
## using nfosearch2.py as an imported module and single source of truth.


import os
import sys
import ctypes
import resource
import errno


PROJECT_DIR = os.path.dirname(os.path.realpath(__file__))
JAIL_ENV = 'MOVIES_UI_JAILED'
JAIL_WEAK_ENV = 'MOVIES_UI_JAIL_ALLOW_WEAK'

# Small, Linux-only hardening pass. This is intentionally explicit and easy to
# remove. It does not try to be a generic sandbox framework.
#
# This jail does not:
# * hide the whole filesystem
# * block all D-Bus or display-server access
# * replace a real sandbox
# * make WebKit harmless
# * implement seccomp/Landlock/chroot/pivot_root
# * provide container isolation
if sys.platform.startswith('linux'):
    LIBC = ctypes.CDLL(None, use_errno=True)

    CLONE_NEWUTS = 0x04000000
    CLONE_NEWIPC = 0x08000000
    CLONE_NEWNET = 0x40000000
    PR_SET_DUMPABLE = 4
    PR_SET_NO_NEW_PRIVS = 38


    def _jail_abort(message):
        print(f'[movies-ui jail] abort: {message}', file=sys.stderr)
        raise SystemExit(126)


    def _libc_call(name, *args):
        fn = getattr(LIBC, name)
        rc = fn(*args)
        if rc != 0:
            err = ctypes.get_errno()
            return False, err, os.strerror(err)
        return True, 0, 'ok'


    def _unshare_namespace(flag, label, required=False):
        ok, err, detail = _libc_call('unshare', ctypes.c_int(flag))
        if ok:
            os.environ[f'MOVIES_UI_JAIL_{label.upper()}'] = 'ok'
            return True
        os.environ[f'MOVIES_UI_JAIL_{label.upper()}'] = f'fail: {detail}'
        if required and os.environ.get(JAIL_WEAK_ENV) != '1':
            _jail_abort(f'{label} failed: {detail} (set {JAIL_WEAK_ENV}=1 for development-only weak mode)')
        print(f'[movies-ui jail] warning: {label} failed: {detail}', file=sys.stderr)
        return False


    def _set_no_new_privs():
        ok, err, detail = _libc_call(
            'prctl',
            ctypes.c_int(PR_SET_NO_NEW_PRIVS),
            ctypes.c_ulong(1),
            ctypes.c_ulong(0),
            ctypes.c_ulong(0),
            ctypes.c_ulong(0),
        )
        os.environ['MOVIES_UI_JAIL_NO_NEW_PRIVS'] = 'ok' if ok else f'fail: {detail}'
        if not ok:
            _jail_abort(f'no_new_privs failed: {detail}')


    def _disable_core_dumps():
        status = 'disabled'
        try:
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except (OSError, ValueError) as exc:
            status = f'warn: setrlimit failed: {exc}'
            print(f'[movies-ui jail] warning: {status}', file=sys.stderr)
        ok, err, detail = _libc_call(
            'prctl',
            ctypes.c_int(PR_SET_DUMPABLE),
            ctypes.c_ulong(0),
            ctypes.c_ulong(0),
            ctypes.c_ulong(0),
            ctypes.c_ulong(0),
        )
        if not ok and err != errno.EINVAL:
            status = f'{status}; prctl warn: {detail}'
            print(f'[movies-ui jail] warning: PR_SET_DUMPABLE failed: {detail}', file=sys.stderr)
        os.environ['MOVIES_UI_JAIL_CORE_DUMPS'] = status


    def _set_modest_resource_limits():
        try:
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            target = min(max(soft, 1024), hard if hard != resource.RLIM_INFINITY else 1024)
            if soft < target:
                resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
        except (OSError, ValueError) as exc:
            print(f'[movies-ui jail] warning: RLIMIT_NOFILE unchanged: {exc}', file=sys.stderr)


    def _resolve_operator_user():
        import pwd

        try:
            return pwd.getpwnam('operator')
        except KeyError:
            _jail_abort('refusing to run GTK/WebKit as root; operator user cannot be resolved')


    def _cache_owner_ok(cache_dir):
        return 'yes' if os.path.isdir(cache_dir) and os.access(cache_dir, os.W_OK | os.X_OK) else 'no'


    def _prepare_cache_dir(uid, gid):
        script_dir = os.path.dirname(os.path.realpath(__file__))
        cache_dir = os.path.join(script_dir, '.cache')
        if os.path.islink(cache_dir):
            _jail_abort(f'refusing to use symlinked cache directory: {cache_dir}')
        try:
            os.makedirs(cache_dir, exist_ok=True)
            os.chown(cache_dir, uid, gid)
            os.chmod(cache_dir, 0o700)
        except OSError as exc:
            _jail_abort(f'failed to prepare cache directory {cache_dir}: {exc}')
        os.environ['MOVIES_UI_JAIL_CACHE_DIR'] = cache_dir
        return cache_dir


    def _make_jail_dirs(cache_dir, uid, gid, create_runtime):
        home = os.path.join(cache_dir, 'jail-home')
        runtime = os.path.join(cache_dir, 'jail-runtime')
        tmp = os.path.join(cache_dir, 'jail-tmp')
        paths = [
            home,
            tmp,
            os.path.join(home, '.cache'),
            os.path.join(home, '.config'),
            os.path.join(home, '.local', 'share'),
        ]
        if create_runtime:
            paths.append(runtime)
        for path in paths:
            if os.path.islink(path):
                _jail_abort(f'refusing to use symlinked jail directory: {path}')
            try:
                os.makedirs(path, mode=0o700, exist_ok=True)
                os.chown(path, uid, gid)
                os.chmod(path, 0o700)
            except OSError as exc:
                _jail_abort(f'failed to prepare jail directory {path}: {exc}')
        return home, runtime if create_runtime else None, tmp


    def _scrub_environment(home, runtime, tmp):
        original = dict(os.environ)
        keep_names = {
            'DISPLAY',
            'WAYLAND_DISPLAY',
            'XAUTHORITY',
            'XDG_RUNTIME_DIR',
            'DBUS_SESSION_BUS_ADDRESS',
            'PATH',
            'LANG',
            'LANGUAGE',
            'TERM',
            'SUDO_UID',
            'SUDO_GID',
            JAIL_WEAK_ENV,
        }
        kept_prefixes = ('LC_', 'MOVIES_UI_JAIL_')
        scrub_prefixes = ('GIT_', 'AWS_', 'GITHUB_', 'OPENAI_')
        scrub_names = {
            'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
            'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy',
            'SSH_AUTH_SOCK', 'SSH_AGENT_PID', 'LD_PRELOAD',
            'LD_LIBRARY_PATH', 'PYTHONPATH',
        }
        os.environ.clear()
        for key, value in original.items():
            if key in scrub_names or any(key.startswith(prefix) for prefix in scrub_prefixes):
                continue
            if key in keep_names or any(key.startswith(prefix) for prefix in kept_prefixes):
                os.environ[key] = value
        os.environ.setdefault('PATH', '/usr/local/bin:/usr/bin:/bin')
        os.environ['HOME'] = home
        os.environ['TMPDIR'] = tmp
        os.environ['XDG_CACHE_HOME'] = os.path.join(home, '.cache')
        os.environ['XDG_CONFIG_HOME'] = os.path.join(home, '.config')
        os.environ['XDG_DATA_HOME'] = os.path.join(home, '.local', 'share')
        if runtime is not None:
            os.environ.setdefault('XDG_RUNTIME_DIR', runtime)
        os.environ['MOVIES_UI_JAIL_FAKE_HOME'] = home


    def _drop_root_privileges(started_as_root, operator_pw):
        os.environ['MOVIES_UI_JAIL_STARTED_AS_ROOT'] = 'yes' if started_as_root else 'no'
        os.environ['MOVIES_UI_JAIL_DROPPED_PRIVILEGES'] = 'no'
        if not started_as_root:
            return

        import grp

        uid = operator_pw.pw_uid
        gid = operator_pw.pw_gid
        username = operator_pw.pw_name

        if uid == 0 or gid == 0:
            _jail_abort('refusing to drop privileges to root')
        try:
            grp.getgrgid(gid)
        except KeyError:
            _jail_abort(f'refusing to drop privileges to unknown gid {gid}')
        try:
            os.initgroups(username, gid)
            os.setgid(gid)
            os.setuid(uid)
        except OSError as exc:
            _jail_abort(f'failed to drop root privileges: {exc}')
        if os.getuid() == 0 or os.geteuid() == 0:
            _jail_abort('privilege drop verification failed')
        os.environ['MOVIES_UI_JAIL_DROPPED_PRIVILEGES'] = 'yes'
        os.environ.pop('SUDO_UID', None)
        os.environ.pop('SUDO_GID', None)


    def _close_inherited_fds():
        try:
            max_fd = os.sysconf('SC_OPEN_MAX')
        except (AttributeError, ValueError):
            max_fd = 1024
        max_fd = min(int(max_fd), 4096)
        for fd in range(3, max_fd):
            try:
                os.close(fd)
            except OSError:
                pass


    def _network_default_route_visible():
        try:
            with open('/proc/net/route', 'r', encoding='utf-8') as routes:
                next(routes, None)
                for line in routes:
                    fields = line.split()
                    if len(fields) > 2 and fields[1] == '00000000' and fields[0] != 'lo':
                        return 'yes'
        except OSError as exc:
            return f'unknown: {exc}'
        return 'no'


    def _net_namespace_link():
        try:
            return os.readlink('/proc/self/ns/net')
        except OSError as exc:
            return f'unavailable: {exc}'


    def _runtime_user_name():
        import pwd

        try:
            return pwd.getpwuid(os.getuid()).pw_name
        except KeyError:
            return 'unknown'


    def _print_jail_report():
        cache_dir = os.environ.get('MOVIES_UI_JAIL_CACHE_DIR', os.path.join(PROJECT_DIR, '.cache'))
        print('[movies-ui jail]')
        print('  linux: yes')
        print('  reexec: yes')
        print(f"  started_as_root: {os.environ.get('MOVIES_UI_JAIL_STARTED_AS_ROOT', 'no')}")
        print(f"  dropped_privileges: {os.environ.get('MOVIES_UI_JAIL_DROPPED_PRIVILEGES', 'no')}")
        print(f'  runtime_uid: {os.getuid()}')
        print(f'  runtime_user: {_runtime_user_name()}')
        print(f'  cache_dir: {cache_dir}')
        print(f'  cache_owner_ok: {_cache_owner_ok(cache_dir)}')
        print(f"  tmpdir: {os.environ.get('TMPDIR', '')}")
        print(f"  xdg_runtime_dir: {os.environ.get('XDG_RUNTIME_DIR', '')}")
        print(f"  no_new_privs: {os.environ.get('MOVIES_UI_JAIL_NO_NEW_PRIVS', 'unknown')}")
        print(f"  newnet: {os.environ.get('MOVIES_UI_JAIL_NEWNET', 'unknown')}")
        print(f"  newipc: {os.environ.get('MOVIES_UI_JAIL_NEWIPC', 'unknown')}")
        print(f"  newuts: {os.environ.get('MOVIES_UI_JAIL_NEWUTS', 'unknown')}")
        print(f"  core_dumps: {os.environ.get('MOVIES_UI_JAIL_CORE_DUMPS', 'unknown')}")
        print(f"  fake_home: {os.environ.get('MOVIES_UI_JAIL_FAKE_HOME', '')}")
        print(f'  net_namespace: {_net_namespace_link()}')
        print(f'  network_default_route_visible: {_network_default_route_visible()}')
        print('  note: root was used only for namespace setup, not for GTK/WebKit runtime')
        print('  note: not a full sandbox; filesystem and display/session access remain')


    def _enter_jail_then_reexec():
        started_as_root = os.geteuid() == 0
        operator_pw = _resolve_operator_user() if started_as_root else None
        uid = operator_pw.pw_uid if operator_pw else os.getuid()
        gid = operator_pw.pw_gid if operator_pw else os.getgid()
        create_runtime = not os.environ.get('XDG_RUNTIME_DIR')
        cache_dir = _prepare_cache_dir(uid, gid)
        home, runtime, tmp = _make_jail_dirs(cache_dir, uid, gid, create_runtime)
        _set_no_new_privs()
        _disable_core_dumps()
        _unshare_namespace(CLONE_NEWNET, 'newnet', required=True)
        _unshare_namespace(CLONE_NEWIPC, 'newipc', required=False)
        _unshare_namespace(CLONE_NEWUTS, 'newuts', required=False)
        _set_modest_resource_limits()
        _scrub_environment(home, runtime, tmp)
        _drop_root_privileges(started_as_root, operator_pw)
        if not os.path.isdir(cache_dir):
            _jail_abort(f'cache directory missing after privilege drop: {cache_dir}')
        if _cache_owner_ok(cache_dir) != 'yes':
            _jail_abort(f'cache directory is not writable/traversable by runtime user: {cache_dir}')
        _close_inherited_fds()
        os.environ[JAIL_ENV] = '1'
        os.execv(sys.executable, [sys.executable] + sys.argv)


    if os.environ.get(JAIL_ENV) != '1':
        _enter_jail_then_reexec()
    else:
        _print_jail_report()
        if os.getuid() == 0 or os.geteuid() == 0:
            _jail_abort('refusing to import GTK/WebKit while still running as root')

print('changing dir to '+PROJECT_DIR)
os.chdir(PROJECT_DIR)

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('WebKit2', '4.0')
from gi.repository import Gtk, WebKit2, Gio, GLib

import os, threading, json, ast, subprocess, base64, mimetypes, secrets, sys, io, contextlib, importlib.util
from urllib.parse import unquote_to_bytes, urlparse
from time import sleep

api_path = '/1/projects/NFO_parser_python_project/nfosearch2.py'

# Import nfosearch2.py as the single source of truth instead of shelling out
# or reading its pickle cache separately from this UI layer.
spec = importlib.util.spec_from_file_location('nfosearch2', api_path)
nfo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nfo)
nfosearch_lock = threading.Lock()
nfo.load_db()

def _format_nfosearch_result(result, multiline_list=False):
    if result is None:
        return 'None'
    if isinstance(result, set):
        result = sorted(list(result))
    if multiline_list and isinstance(result, (list, tuple)):
        return '\n'.join([str(item) for item in result])
    return str(result)


def _call_nfosearch_function(function, *args, multiline_list=False, **kwargs):
    stdout = io.StringIO()

    with nfosearch_lock:
        with contextlib.redirect_stdout(stdout):
            result = function(*args, **kwargs)

    printed = stdout.getvalue().strip()
    if printed:
        return printed
    return _format_nfosearch_result(result, multiline_list=multiline_list)


def run_nfosearch_direct(args):
    values = [str(arg) for arg in args.values()]
    if not values:
        return ''

    flag = values[0]
    value = values[1] if len(values) > 1 else None

    if flag in ('--genre', '-g'):
        return _call_nfosearch_function(nfo.listByGenre, value, nfo.DIRS, multiline_list=True)
    if flag in ('--all', '-r'):
        return _call_nfosearch_function(nfo.listAllGenres, nfo.DIRS)
    if flag in ('--file', '-f'):
        return _call_nfosearch_function(nfo.findMovieFileByTitle, nfo.DIRS, value)
    if flag in ('--byactor', '-b'):
        return _call_nfosearch_function(nfo.findMoviesByActor, value, nfo.DIRS)
    if flag in ('--actorsbymovie', '-o'):
        return _call_nfosearch_function(nfo.findActorsForOneMovie, nfo.DIRS, value)
    if flag in ('--actors', '-a'):
        return _call_nfosearch_function(nfo.findActors, nfo.DIRS)
    if flag in ('--updateallactors', '-z'):
        return _call_nfosearch_function(nfo.updateAllActors, nfo.DIRS)
    if flag in ('--plot', '-p'):
        return _call_nfosearch_function(nfo.findPlotByTitle, nfo.DIRS, value)
    if flag in ('--poster', '-x'):
        return _call_nfosearch_function(nfo.findPosterByTitle, value, nfo.DIRS)
    if flag in ('--actorimage', '-y'):
        return _call_nfosearch_function(nfo.findActorImage, value)
    if flag in ('--nopictures', '-n'):
        return _call_nfosearch_function(nfo.list_actors_with_no_picture, nfo.DIRS, refresh=True)

    return ''

# Native WebKit message bridge. All backend work is exposed through
# semantic bridge actions instead of local web routes.
BRIDGE_ACTIONS = {}


def bridge_action(action):
    def register(func):
        BRIDGE_ACTIONS[action] = func
        return func
    return register


@bridge_action('__ping__')
def bridge_ping(data):
    return {'pong': True, 'echo': data}

RESOURCE_TOKENS = {}
RESOURCE_TOKEN_LOCK = threading.Lock()
APPTHUMB_SCHEME = 'appthumb'


def _image_payload_to_bytes(payload):
    if not payload or payload == 'None':
        return None, None
    payload = payload.strip()
    if payload.startswith('data:'):
        header, encoded = payload.split(',', 1)
        mime_type = header[5:].split(';', 1)[0] or 'application/octet-stream'
        if ';base64' in header:
            return base64.b64decode(encoded), mime_type
        return unquote_to_bytes(encoded), mime_type

    path = payload
    if payload.startswith('file://'):
        path = urlparse(payload).path
    if os.path.exists(path) and os.path.isfile(path):
        mime_type = mimetypes.guess_type(path)[0] or 'application/octet-stream'
        with open(path, 'rb') as f:
            return f.read(), mime_type

    raise ValueError('poster payload was not a data URI or readable file')


def _mint_resource_token(data, mime_type):
    token = secrets.token_urlsafe(18)
    with RESOURCE_TOKEN_LOCK:
        RESOURCE_TOKENS[token] = {'data': data, 'mime_type': mime_type or 'application/octet-stream'}
    return token




def _json_safe(value):
    if isinstance(value, set):
        return sorted([_json_safe(item) for item in value])
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def _required_text(data, field, action):
    value = data.get(field) if isinstance(data, dict) else None
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'{action} requires a non-empty {field}')
    return value.strip()


def _parse_nfosearch_list(value):
    if value is None or value == 'None':
        return []
    if isinstance(value, set):
        return sorted(value)
    if isinstance(value, (list, tuple)):
        return list(value)
    if isinstance(value, str):
        text = value.strip()
        if not text or text == 'None':
            return []
        try:
            parsed = ast.literal_eval(text)
        except (SyntaxError, ValueError):
            parsed = None
        if isinstance(parsed, set):
            return sorted(parsed)
        if isinstance(parsed, (list, tuple)):
            return list(parsed)
        if isinstance(parsed, dict):
            return list(parsed.values())
        return [line for line in text.splitlines() if line.strip()]
    return [value]


@bridge_action('get_library_index')
def bridge_get_library_index(data):
    by_genre = _json_safe(nfo.db.get('by_genre', {}))
    # Keep the legacy key name for JS compatibility, but do not send local paths.
    moviepath = nfo.db.get('moviepath', {})
    return {
        'genres': sorted(list(by_genre.keys())),
        'by_genre': by_genre,
        'moviepath': {str(title): True for title in moviepath.keys()},
    }


@bridge_action('get_movie_plot')
def bridge_get_movie_plot(data):
    title = _required_text(data, 'title', 'get_movie_plot')
    plot = _call_nfosearch_function(nfo.findPlotByTitle, nfo.DIRS, title)
    if plot == 'None':
        plot = ''
    return {'title': title, 'plot': plot.replace("'''", '')}


@bridge_action('get_movie_poster')
def bridge_get_movie_poster(data):
    title = data.get('title') if isinstance(data, dict) else None
    if not isinstance(title, str) or not title.strip():
        raise ValueError('get_movie_poster requires a non-empty title')
    title = title.strip()
    poster_payload = _call_nfosearch_function(nfo.findPosterByTitle, title, nfo.DIRS)
    poster_bytes, mime_type = _image_payload_to_bytes(poster_payload)
    if poster_bytes is None:
        return {'title': title, 'available': False}
    token = _mint_resource_token(poster_bytes, mime_type)
    print(f"DEBUG: {title}: {APPTHUMB_SCHEME}://token/{token}")
    return {
        'title': title,
        'available': True,
        'poster_token': token,
        'poster_uri': f'{APPTHUMB_SCHEME}://token/{token}',

        # Durable cache payload.
        # nfosearch2 already returned this as the original poster dataURL.
        # JS stores this in IndexedDB; do not store appthumb:// tokens.
        'poster_data': poster_payload,
    }



@bridge_action('get_actors_for_movie')
def bridge_get_actors_for_movie(data):
    title = _required_text(data, 'title', 'get_actors_for_movie')
    actors = _call_nfosearch_function(nfo.findActorsForOneMovie, nfo.DIRS, title)
    return {'title': title, 'actors': _parse_nfosearch_list(actors)}


@bridge_action('get_actor_index')
def bridge_get_actor_index(data):
    actors = _call_nfosearch_function(nfo.findActors, nfo.DIRS)
    return {'actors': _parse_nfosearch_list(actors)}


@bridge_action('get_actor_image')
def bridge_get_actor_image(data):
    name = _required_text(data, 'name', 'get_actor_image')
    image_payload = _call_nfosearch_function(nfo.findActorImage, name)
    image_bytes, mime_type = _image_payload_to_bytes(image_payload)
    if image_bytes is None:
        return {'name': name, 'available': False}
    token = _mint_resource_token(image_bytes, mime_type)
    return {
        'name': name,
        'available': True,
        'actor_image_token': token,
        'actor_image_uri': f'{APPTHUMB_SCHEME}://token/{token}',
    }


@bridge_action('get_movies_for_actor')
def bridge_get_movies_for_actor(data):
    name = _required_text(data, 'name', 'get_movies_for_actor')
    movies = _call_nfosearch_function(nfo.findMoviesByActor, name, nfo.DIRS)
    return {'name': name, 'movies': _parse_nfosearch_list(movies)}


@bridge_action('play_movie')
def bridge_play_movie(data):
    title = _required_text(data, 'title', 'play_movie')
    with nfosearch_lock:
        movie_file = nfo.findMovieFileByTitle(nfo.DIRS, title)
    if not movie_file or movie_file == 'None':
        return {'title': title, 'success': False, 'error': 'movie file not found'}
    location = os.path.dirname(movie_file)
    print('got title: '+title)
    print('launching movie directory for title without exposing path to JS')
    player_env = os.environ.copy()
    player_env["QT_QPA_PLATFORMTHEME"] = "qt5ct"
    subprocess.Popen(['vlcshortcut', location], env=player_env)
    return {'title': title, 'success': True}

def appthumb_uri_handler(request, user_data):
    uri = request.get_uri()
    parsed = urlparse(uri)
    token = ''
    if parsed.netloc == 'token':
        token = parsed.path.lstrip('/')
    with RESOURCE_TOKEN_LOCK:
        resource = RESOURCE_TOKENS.get(token)
    if resource is None:
        body = b'appthumb token not found'
        stream = Gio.MemoryInputStream.new_from_bytes(GLib.Bytes.new(body))
        request.finish(stream, len(body), 'text/plain')
        return
    stream = Gio.MemoryInputStream.new_from_bytes(GLib.Bytes.new(resource['data']))
    request.finish(stream, len(resource['data']), resource['mime_type'])


def register_appthumb_scheme(web_context):
    web_context.register_uri_scheme(APPTHUMB_SCHEME, appthumb_uri_handler, None)


def _js_literal(value):
    return json.dumps(value).replace('</', '<\\/')


def send_bridge_response(message_id, ok=True, result=None, error=None):
    global web_view
    response = {'id': message_id, 'ok': ok}
    if ok:
        response['result'] = result
    else:
        response['error'] = str(error)
    web_view.run_javascript(f'window.App && window.App.receive({_js_literal(response)});')
    return False


def queue_bridge_response(message_id, ok=True, result=None, error=None):
    GLib.idle_add(send_bridge_response, message_id, ok, result, error)


def _javascript_result_to_json(js_result):
    js_value = js_result.get_js_value()
    if hasattr(js_value, 'to_json'):
        json_text = js_value.to_json(0)
        if json_text:
            return json_text
    return js_value.to_string()


def _run_bridge_job(message):
    message_id = message.get('id')
    action = message.get('action')
    data = message.get('data', {})
    handler = BRIDGE_ACTIONS.get(action)
    if handler is None:
        queue_bridge_response(message_id, ok=False, error=f'unknown bridge action: {action}')
        return
    try:
        result = handler(data)
        queue_bridge_response(message_id, ok=True, result=result)
    except Exception as e:
        queue_bridge_response(message_id, ok=False, error=e)


def on_app_message(user_content_manager, js_result):
    try:
        payload = _javascript_result_to_json(js_result)
        message = json.loads(payload)
        if isinstance(message, str):
            message = json.loads(message)
        if not isinstance(message, dict):
            raise ValueError('bridge message must be a JSON object')
        if 'id' not in message or 'action' not in message:
            raise ValueError('bridge message requires id and action')
        threading.Thread(target=_run_bridge_job, args=(message,), daemon=True).start()
    except Exception as e:
        print(f'bridge message rejected: {e}')


def register_app_message_handler(web_view):
    user_content_manager = web_view.get_user_content_manager()
    user_content_manager.register_script_message_handler('app')
    user_content_manager.connect('script-message-received::app', on_app_message)

#WebKit2 WebView instance signal handlers:
def on_load_changed(web_view, load_event):
    if load_event == WebKit2.LoadEvent.FINISHED:
        print("Page loaded successfully!")
        # Things that need to happen post page load?

def on_window_destroy(widget, data=None):
    print("Window closing...")
    Gtk.main_quit()
    sleep(0.2)
    os._exit(0)


def load_initial_html(web_view):
    project_dir = os.path.dirname(os.path.realpath(__file__))
    index_path = os.path.join(project_dir, 'index.html')
    css_path = os.path.join(project_dir, 'css', 'my.css')
    with open(index_path, 'r', encoding='utf-8') as f:
        html = f.read()
    with open(css_path, 'r', encoding='utf-8') as f:
        css = f.read()
    html = html.replace('<link rel="stylesheet" href="css/my.css">', '<style data-app-inline="css/my.css">'+css.replace('</', '<\\/')+'</style>')
    web_view.load_html(html, 'app://movies-ui/')

def main():
    global web_view

    # Create a new window
    window = Gtk.Window(title="webkit-ui")
    window.set_default_size(800, 400)

    #altering storage settings:
    #you have to set up the 'context' object __before__ creating the WebView instance, just for convolutedness:
    local_dir = os.path.dirname(os.path.realpath(__file__))+"/.cache" #gets the dir _this_ script resides in.
    print(f'CACHE DIR SET TO: {local_dir}')
    #make the data manager with the base_data_directory set to script's home:
    web_context_data_manager=WebKit2.WebsiteDataManager(base_data_directory = local_dir+'/webkit')
    #make the context with the correct data_manager so the setting propagates 'up':
    web_view_context = WebKit2.WebContext(website_data_manager = web_context_data_manager)
    register_appthumb_scheme(web_view_context)
    #make the webview instance with the context. Holy Mother Of God
    web_view = WebKit2.WebView.new_with_context(web_view_context)

    register_app_message_handler(web_view)

    #web_view/gtk window signals:
    web_view.connect('load-changed', on_load_changed) #this is changed, NOT fully loaded.
    window.connect('destroy', on_window_destroy)
    #web_view.connect("context-menu", on_popup_menu)

    #web_view settings
    settings = web_view.get_settings()
    settings.set_property('enable-plugins', True)
    settings.set_property('enable-javascript', True)
    settings.set_property('enable-developer-extras', True)
    settings.set_property('enable_write_console_messages_to_stdout', True)
    settings.set_default_font_size(12)

    # Load the local webpage through the Python bootloader.
    load_initial_html(web_view)

    # Add the view to the window
    window.add(web_view)

    # Show the window
    window.show_all()

    # Start the GTK main loop
    Gtk.main()


if __name__ == "__main__":
    main()
