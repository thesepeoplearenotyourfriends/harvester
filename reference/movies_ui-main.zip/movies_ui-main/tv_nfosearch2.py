#!/usr/bin/env python3
"""
tv_nfosearch2.py

A local TV-library companion to nfosearch2.py.

Library contract
----------------

TV_SHOWS_DIR/
  Some Show - Season 01/
    show.nfo
    poster.jpg | poster.png
    episode files...
  Another Show - Season 02/
    show.nfo
    poster.jpg | poster.png
  .actors/
    Actor_Name.jpg

Each immediate, non-hidden child directory of DIRS is one searchable local
season record.  The folder name is the display title.  This matters because
many season folders share the same <title> in their show.nfo; keeping the
folder name prevents "Some Show" season 1 through season 9 from collapsing
into one search result.

The public API deliberately uses TV and season vocabulary.  It does not carry
movie-shaped compatibility aliases into the production application.

The library is parsed once at application launch into run-local Python state.
Poster and actor files remain on disk as the source of truth.
"""

from __future__ import annotations

import argparse
import base64
import io
import json
import os
import re
import sys
import xml.etree.ElementTree as et
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import unicodedata


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Top-level TV library locations.  Each immediate child directory is treated
# as one show/season record, for example: "Fallout - Season 01".
DIRS = ["/mnt/2tb/TV"]

# Episode-file candidates for the command-line ``--file`` operation.
VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".m4v", ".avi", ".webm", ".mov", ".ts", ".m2ts",
}

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}

db: Dict[str, Any] = {}


# Runtime state is rebuilt explicitly at process launch; no persistent database.

# ---------------------------------------------------------------------------
# Text and filesystem helpers
# ---------------------------------------------------------------------------

def norm_text(value: Any) -> str:
    """Make title/name comparisons forgiving without making them fuzzy."""
    if not value:
        return ""

    value = unicodedata.normalize("NFKD", str(value))
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = value.lower().replace("&", " and ")
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def clean_text(value: Optional[str]) -> str:
    """Return stripped XML text, or an empty string when an element is absent."""
    return value.strip() if isinstance(value, str) and value.strip() else ""


def safe_actor_stem(name: str) -> str:
    """Match the deliberately simple .actors/Actor_Name.jpg convention."""
    name = (name or "").strip()
    name = re.sub(r"[\\/:]+", "_", name)
    name = re.sub(r"\s+", "_", name)
    name = re.sub(r"[^A-Za-z0-9._'()&+-]+", "_", name)
    name = name.strip("._ ")
    return name or "unknown_actor"


def visible_child_directories(library_dir: str) -> Iterable[Path]:
    """Yield immediate title/season directories, ignoring .actors and dot dirs."""
    root = Path(library_dir)
    try:
        children = sorted(root.iterdir(), key=lambda item: item.name.casefold())
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return

    for child in children:
        try:
            is_dir = child.is_dir()
        except OSError:
            continue

        if is_dir and not child.name.startswith("."):
            yield child


def nfo_for_folder(folder: Path) -> Optional[Path]:
    """
    Return the preferred show.nfo for a season folder.

    The generated-TV convention is exactly show.nfo.  A lone legacy .nfo is
    accepted as a convenience so the tool remains useful while a library is
    still being filled in.
    """
    preferred = folder / "show.nfo"
    if preferred.is_file():
        return preferred

    try:
        candidates = sorted(
            (
                item for item in folder.iterdir()
                if item.is_file() and item.suffix.lower() == ".nfo"
            ),
            key=lambda item: item.name.casefold(),
        )
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return None

    return candidates[0] if len(candidates) == 1 else None


def poster_for_folder(folder: Path) -> Optional[Path]:
    """Find a local poster in a season folder, preferring the conventional name."""
    exact_names = ("poster.jpg", "poster.jpeg", "poster.png", "poster.webp")

    for name in exact_names:
        candidate = folder / name
        if candidate.is_file():
            return candidate

    try:
        candidates = sorted(
            (
                item for item in folder.iterdir()
                if item.is_file()
                and item.suffix.lower() in IMAGE_EXTENSIONS
                and "poster" in item.name.casefold()
            ),
            key=lambda item: item.name.casefold(),
        )
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return None

    return candidates[0] if candidates else None


def first_episode_file(folder: Path) -> Optional[str]:
    """Return the first ordinary-looking local episode file in a season folder."""
    try:
        candidates = sorted(folder.iterdir(), key=lambda item: item.name.casefold())
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return None

    for item in candidates:
        if not item.is_file() or item.suffix.lower() not in VIDEO_EXTENSIONS:
            continue
        name = item.name.casefold()
        if "trailer" in name or "sample" in name:
            continue
        return str(item.resolve())

    return None


def find_directories_without_nfo_files(dir: Optional[str] = None) -> List[str]:
    """
    Return immediate visible TV season folders that have no show.nfo/.nfo.

    This is the TV counterpart to the movie helper's GENRE == "none" path.
    It intentionally does not recurse: season folders are the record boundary.
    """
    library_dir = dir or DIRS[0]
    missing = [folder.name for folder in visible_child_directories(library_dir)
               if nfo_for_folder(folder) is None]
    return sorted(missing, key=str.casefold)


# ---------------------------------------------------------------------------
# NFO parsing and index construction
# ---------------------------------------------------------------------------

def _first_text(root: et.Element, *tags: str) -> str:
    for tag in tags:
        value = clean_text(root.findtext(tag))
        if value:
            return value
    return ""


def _parse_int(value: Optional[str]) -> Optional[int]:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def parse_show_nfo(nfo_path: Path, folder: Path) -> Optional[Dict[str, Any]]:
    """Parse one show.nfo into the compact record used by the TV search index."""
    try:
        root = et.parse(nfo_path).getroot()
    except (et.ParseError, OSError):
        return None

    title = _first_text(root, "title", "originaltitle") or folder.name
    original_title = _first_text(root, "originaltitle")
    plot = _first_text(root, "plot", "outline")

    genres = sorted(
        {clean_text(node.text) for node in root.findall("genre") if clean_text(node.text)},
        key=str.casefold,
    )

    actors: List[Dict[str, Any]] = []
    for actor_node in root.findall(".//actor"):
        name = clean_text(actor_node.findtext("name"))
        if not name:
            continue

        order = _parse_int(actor_node.findtext("order"))
        actors.append({
            "name": name,
            "role": clean_text(actor_node.findtext("role")),
            "order": order,
        })

    actors.sort(key=lambda item: (
        item["order"] is None,
        item["order"] if item["order"] is not None else 999999,
        item["name"].casefold(),
    ))

    poster = poster_for_folder(folder)

    return {
        "key": str(nfo_path.resolve()),
        "nfo": str(nfo_path.resolve()),
        "folder": str(folder.resolve()),
        "display_title": folder.name,
        "title": title,
        "originaltitle": original_title,
        "sorttitle": _first_text(root, "sorttitle"),
        "plot": plot,
        "outline": _first_text(root, "outline"),
        "year": _first_text(root, "year"),
        "premiered": _first_text(root, "premiered"),
        "genres": genres,
        "actors": actors,
        "poster": str(poster.resolve()) if poster else None,
    }


def library_signature(dirs: Iterable[str]) -> Tuple[Tuple[Any, ...], ...]:
    """
    Build a cheap signature of visible season folders and their NFO files.

    We inspect one level only.  This detects new/deleted season folders and
    NFO edits without walking episode files or parsing XML when nothing changed.
    """
    parts: List[Tuple[Any, ...]] = []

    for directory in dirs:
        root = Path(directory)
        try:
            root_id = str(root.resolve())
        except OSError:
            root_id = str(root)

        for folder in visible_child_directories(str(root)):
            nfo = nfo_for_folder(folder)
            if nfo:
                try:
                    st = nfo.stat()
                    nfo_state: Tuple[Any, ...] = (str(nfo.resolve()), st.st_mtime_ns, st.st_size)
                except OSError:
                    nfo_state = (str(nfo), "unreadable")
            else:
                nfo_state = (None,)

            parts.append((root_id, folder.name, *nfo_state))

    return tuple(parts)


def _build_index(dirs: Iterable[str]) -> Dict[str, Any]:
    """Parse all present show.nfo files and build the TV-specific lookup maps."""
    records: List[Dict[str, Any]] = []

    for directory in dirs:
        for folder in visible_child_directories(directory):
            nfo = nfo_for_folder(folder)
            if not nfo:
                continue

            record = parse_show_nfo(nfo, folder)
            if record:
                records.append(record)

    records.sort(key=lambda record: record["display_title"].casefold())

    by_display: Dict[str, List[int]] = defaultdict(list)
    by_title: Dict[str, List[int]] = defaultdict(list)
    by_actor: Dict[str, List[str]] = defaultdict(list)
    by_genre: Dict[str, List[str]] = defaultdict(list)
    all_actors: Dict[str, str] = {}
    all_genres: Dict[str, str] = {}

    for index, record in enumerate(records):
        display = record["display_title"]
        by_display[norm_text(display)].append(index)

        for candidate in (record.get("title"), record.get("originaltitle"), record.get("sorttitle")):
            key = norm_text(candidate)
            if key:
                by_title[key].append(index)

        for actor in record["actors"]:
            name = actor["name"]
            actor_key = norm_text(name)
            if not actor_key:
                continue
            all_actors.setdefault(actor_key, name)
            by_actor[actor_key].append(display)

        for genre in record["genres"]:
            genre_key = norm_text(genre)
            if not genre_key:
                continue
            all_genres.setdefault(genre_key, genre)
            by_genre[genre_key].append(display)

    # Deduplicate and sort index values.  This is especially useful when one
    # show's title/originaltitle/sorttitle normalize to the same thing.
    indexed_display = {
        key: sorted(values) for key, values in by_display.items()
    }
    indexed_title = {
        key: sorted(set(values)) for key, values in by_title.items()
    }
    indexed_actor = {
        key: sorted(set(values), key=str.casefold) for key, values in by_actor.items()
    }
    indexed_genre = {
        key: sorted(set(values), key=str.casefold) for key, values in by_genre.items()
    }

    return {"records": records, "_by_display": indexed_display,
            "_by_title": indexed_title, "seasons_by_actor": indexed_actor,
            "by_genre": indexed_genre,
            "all_actors": sorted(all_actors.values(), key=str.casefold),
            "all_genres": sorted(all_genres.values(), key=str.casefold),
            "season_folders": {}, "plot": {}}


def rebuild_index(dirs: Optional[Iterable[str]] = None) -> None:
    """Build a complete replacement runtime index from the TV library."""
    global db
    replacement = _build_index(list(dirs or DIRS))
    db = replacement


def build_index(dirs: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    """Return a complete TV index without changing the installed runtime state."""
    return _build_index(list(dirs or DIRS))


def _require_index() -> None:
    if "records" not in db:
        raise RuntimeError("TV library index has not been initialized")

def _matching_records(title: str, dirs: Optional[Iterable[str]] = None) -> List[Dict[str, Any]]:
    """
    Resolve a UI/CLI title to season records.

    Folder-name matches win.  That lets a caller ask for exactly
    "Show Name - Season 02" even though every season NFO says <title>Show Name</title>.
    A bare show name falls back to the matching NFO titles, usually returning
    several season records; callers that need one choose the first sorted one.
    """
    _require_index()
    wanted = norm_text(title)
    if not wanted:
        return []

    records = db["records"]
    display_matches = db.get("_by_display", {}).get(wanted, [])
    if display_matches:
        return [records[index] for index in display_matches]

    title_matches = db.get("_by_title", {}).get(wanted, [])
    return [records[index] for index in title_matches]


def _first_matching_record(title: str, dirs: Optional[Iterable[str]] = None) -> Optional[Dict[str, Any]]:
    matches = _matching_records(title, dirs)
    return matches[0] if matches else None


# ---------------------------------------------------------------------------
# Search helpers — same general shape as nfosearch2.py, TV semantics
# ---------------------------------------------------------------------------

def list_by_genre(genre: str, dirs: Iterable[str]) -> List[str]:
    """
    Return display folder names matching a genre.

    GENRE == "none" returns immediate season folders without a local NFO.
    Folder names, rather than <title>, keep same-show seasons distinct.
    """
    _require_index()

    if norm_text(genre) == "none":
        missing: List[str] = []
        for directory in dirs:
            missing.extend(find_directories_without_nfo_files(directory))
        return sorted(set(missing), key=str.casefold)

    return list(db.get("by_genre", {}).get(norm_text(genre), []))


def list_all_genres(dirs: Iterable[str]) -> List[str]:
    """Return all locally present genres, deduplicated and sorted."""
    _require_index()
    return list(db.get("all_genres", []))


def find_actors(dirs: Iterable[str]) -> List[str]:
    """Return all actor names found in indexed TV show NFO files."""
    _require_index()
    return list(db.get("all_actors", []))


def find_seasons_by_actor(actor: str, dirs: Iterable[str]) -> Optional[str]:
    """Return JSON season-folder display titles containing ``actor``."""
    _require_index()
    titles = db.get("seasons_by_actor", {}).get(norm_text(actor), [])
    return json.dumps(titles) if titles else None


def find_season_folder_by_title(dirs: Iterable[str], title: str) -> Optional[str]:
    """Return the local season-folder path for TITLE or display folder name."""
    record = _first_matching_record(title, dirs)
    return record["folder"] if record else None


def find_episode_file_by_title(dirs: Iterable[str], title: str) -> Optional[str]:
    """Return the first ordinary episode file within the resolved season folder."""
    record = _first_matching_record(title, dirs)
    if not record:
        return None

    return first_episode_file(Path(record["folder"]))


def update_all_actors(dirs: Iterable[str]) -> None:
    """
    Warm/rebuild actor-to-season results.

    The old movie version did one full NFO scan per actor.  The TV index creates
    this map during one scan, so -z now refreshes it in one pass rather than
    making 600 familiar faces demand 600 full walks through the library.
    """
    rebuild_index(dirs)
    actor_count = len(db.get("all_actors", []))
    relationship_count = sum(len(value) for value in db.get("seasons_by_actor", {}).values())
    print(f"Actor index refreshed: {actor_count} actors, {relationship_count} local season links.")


def find_actors_for_season(dirs: Iterable[str], season: str) -> str:
    """Return a JSON list of actors for one local season folder/title."""
    record = _first_matching_record(season, dirs)
    if not record:
        return json.dumps([])

    names = [actor["name"] for actor in record.get("actors", []) if actor.get("name")]
    return json.dumps(names)


# ---------------------------------------------------------------------------
# Local image helpers
# ---------------------------------------------------------------------------

def image_file_to_data_url(image_path: str, max_size: Tuple[int, int] = (400, 400), quality: int = 85) -> str:
    """
    Resize an image in memory and return a JPEG data URL.

    Pillow stays optional until this feature is invoked, matching the old
    script's dependency posture.
    """
    from PIL import Image

    with Image.open(image_path) as image:
        image.thumbnail(max_size)
        if image.mode not in ("RGB", "L"):
            image = image.convert("RGB")

        output = io.BytesIO()
        image.save(output, "JPEG", quality=quality, optimize=True)

    encoded = base64.b64encode(output.getvalue()).decode("utf-8")
    return f"data:image/jpeg;base64,{encoded}"


def _actor_image_path(actor: str, actor_dir: Optional[str] = None) -> Optional[str]:
    """Find a local mugshot using the simple Actor_Name.jpg convention."""
    directory = Path(actor_dir or (Path(DIRS[0]) / ".actors"))
    if not directory.is_dir():
        return None

    wanted_stem = safe_actor_stem(actor).casefold()
    fallback: Optional[Path] = None

    try:
        files = sorted(directory.iterdir(), key=lambda item: item.name.casefold())
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return None

    for item in files:
        if not item.is_file() or item.suffix.casefold() not in IMAGE_EXTENSIONS:
            continue

        stem = item.stem.casefold()
        if stem == wanted_stem:
            return str(item.resolve())
        if wanted_stem in item.name.casefold() and fallback is None:
            fallback = item

    return str(fallback.resolve()) if fallback else None


def find_actor_image(actor: str) -> Optional[str]:
    """Return a local actor mugshot as a resized base64 JPEG data URL."""
    path = _actor_image_path(actor)
    return image_file_to_data_url(path, max_size=(400, 400)) if path else None


def _actor_dir_signature(actor_dir: str) -> Tuple[Tuple[str, int, int], ...]:
    directory = Path(actor_dir)
    rows: List[Tuple[str, int, int]] = []

    try:
        files = directory.iterdir()
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return tuple()

    for item in files:
        try:
            if item.is_file() and item.suffix.casefold() in IMAGE_EXTENSIONS:
                st = item.stat()
                rows.append((item.name, st.st_mtime_ns, st.st_size))
        except OSError:
            continue

    return tuple(sorted(rows, key=lambda row: row[0].casefold()))


def list_actors_with_no_picture(
    DIRS: Iterable[str],
    actor_dir: Optional[str] = None,
    refresh: bool = False,
) -> List[str]:
    """Return NFO actor names whose simple .actors filename is absent."""
    _require_index()
    active_actor_dir = actor_dir or str(Path(list(DIRS)[0]) / ".actors")
    picture_signature = _actor_dir_signature(active_actor_dir)

    if (
        not refresh
        and "actors_with_no_picture" in db
        and db.get("_actor_picture_signature") == picture_signature
    ):
        return list(db["actors_with_no_picture"])

    missing = [
        actor for actor in db.get("all_actors", [])
        if _actor_image_path(actor, active_actor_dir) is None
    ]
    missing.sort(key=str.casefold)

    db["actors_with_no_picture"] = missing
    db["_actor_picture_signature"] = picture_signature
    db["actor_picture_stats"] = {
        "total_actors": len(db.get("all_actors", [])),
        "actor_image_files": len(picture_signature),
        "missing_pictures": len(missing),
        "with_pictures": len(db.get("all_actors", [])) - len(missing),
        "actor_dir": active_actor_dir,
    }

    return missing


def find_poster_by_title(title: str, dirs: Iterable[str]) -> Optional[str]:
    """Return a local season poster as a resized base64 JPEG data URL."""
    record = _first_matching_record(title, dirs)
    if not record:
        return None

    poster = record.get("poster")
    # Poster files can be added after the NFO index was built.  Check the
    # directory again rather than requiring a cache rebuild for an image.
    if not poster or not Path(poster).is_file():
        found = poster_for_folder(Path(record["folder"]))
        poster = str(found.resolve()) if found else None

    return image_file_to_data_url(poster, max_size=(400, 400)) if poster else None


def find_plot_by_title(dirs: Iterable[str], title: str) -> str:
    """
    Return plot text wrapped in triple quotes, preserving the old API shape.
    """
    _require_index()
    cache_key = norm_text(title)

    if cache_key in db.get("plot", {}):
        return db["plot"][cache_key]

    record = _first_matching_record(title, dirs)
    plot = record.get("plot", "") if record else ""
    result = f"'''{plot}'''"
    db.setdefault("plot", {})[cache_key] = result
    return result


# ---------------------------------------------------------------------------
# Command line interface
# ---------------------------------------------------------------------------

def main() -> None:
    """Parse CLI options and dispatch to the TV search helpers."""
    rebuild_index(DIRS)

    parser = argparse.ArgumentParser(
        description="Search a local TV library organized as <Show> - Season NN/show.nfo."
    )
    parser.add_argument("--genre", "-g", type=str, help="List season folders by genre; use 'none' for folders without NFOs")
    parser.add_argument("--all", "-r", action="store_true", help="List all genres")
    parser.add_argument("--file", "-f", type=str, help="Find first episode file by folder name or show title")
    parser.add_argument("--folder", type=str, help="Find season-folder path by folder name or show title")
    parser.add_argument("--byactor", "-b", type=str, help="List local season folders an actor appears in")
    parser.add_argument("--actorsbyseason", "-o", dest="actorsbyseason", type=str, help="List actors in one season folder/title")
    parser.add_argument("--actors", "-a", action="store_true", help="List all actors")
    parser.add_argument("--updateallactors", "-z", action="store_true", help="Rebuild actor-to-season index")
    parser.add_argument("--plot", "-p", type=str, help="Print plot for a season folder/title")
    parser.add_argument("--poster", "-x", type=str, help="Find local poster; returns a base64 data URL")
    parser.add_argument("--actorimage", "-y", type=str, help="Find local actor image; returns a base64 data URL")
    parser.add_argument("--nopictures", "-n", action="store_true", help="List actors without local mugshots")
    parser.add_argument("--refresh", action="store_true", help="Force a fresh NFO index rebuild before searching")
    args = parser.parse_args()

    if args.refresh:
        rebuild_index(DIRS)

    if args.genre:
        for title in list_by_genre(args.genre, DIRS):
            print(title)
    elif args.all:
        print(list_all_genres(DIRS))
    elif args.file:
        print(find_episode_file_by_title(DIRS, args.file))
    elif args.folder:
        print(find_season_folder_by_title(DIRS, args.folder))
    elif args.byactor:
        print(find_seasons_by_actor(args.byactor, DIRS))
    elif args.plot:
        print(find_plot_by_title(DIRS, args.plot))
    elif args.actors:
        print(find_actors(DIRS))
    elif args.poster:
        print(find_poster_by_title(args.poster, DIRS))
    elif args.actorsbyseason:
        print(find_actors_for_season(DIRS, args.actorsbyseason))
    elif args.updateallactors:
        update_all_actors(DIRS)
    elif args.actorimage:
        print(find_actor_image(args.actorimage))
    elif args.nopictures:
        print(list_actors_with_no_picture(DIRS, refresh=True))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
