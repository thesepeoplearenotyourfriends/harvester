import tempfile
import unittest
from pathlib import Path

import nfosearch2


class MovieIndexTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def movie_dir(self, name, video=None, nfo=None):
        folder = self.root / name
        folder.mkdir()
        if video:
            (folder / video).write_bytes(b"video")
        if nfo is not None:
            (folder / f"{name}.nfo").write_text(nfo, encoding="utf-8")
        return folder

    def test_ordinary_and_lost_found_classification(self):
        self.movie_dir("Valid", "valid.mkv", """<movie><title>First Blood</title>
            <plot>The treatment has angered Rambo to the point of resistance.</plot>
            <genre>action</genre><actor><name>Sylvester Stallone</name></actor></movie>""")
        self.movie_dir("No NFO", "Attenborough.Frogs.mkv")
        self.movie_dir("Scene", "release.mp4", "scene release notes")
        self.movie_dir("Malformed", "broken.avi", "<movie><title>Broken")
        self.movie_dir("Other XML", "wrong.mov", "<episodedetails><title>Episode-shaped Film</title></episodedetails>")
        mixed = self.movie_dir("Mixed NFOs", "mixed.webm", "scene release notes")
        (mixed / "z-valid.nfo").write_text(
            "<movie><title>Mixed Film</title><genre>adventure</genre></movie>", encoding="utf-8")
        broken = self.movie_dir("Many Bad NFOs", "many.m4v", "not xml")
        (broken / "second.nfo").write_text("<movie>", encoding="utf-8")
        self.movie_dir("No Video", nfo="not xml")
        self.movie_dir("Trailer Only", "feature-trailer.mkv")

        index = nfosearch2.build_index([self.root])
        self.assertEqual([record["title"] for record in index["records"]],
                         ["Mixed Film", "Episode-shaped Film", "First Blood"])
        self.assertEqual([record["name"] for record in index["lost_found"]],
                         ["Malformed", "Many Bad NFOs", "No NFO", "Scene"])
        self.assertEqual(nfosearch2.nfo_for_folder(mixed).name, "z-valid.nfo")
        self.assertNotIn("Mixed NFOs", {record["name"] for record in index["lost_found"]})
        self.assertEqual(index["lost_found_by_id"]["no nfo"]["media"], "Attenborough.Frogs.mkv")
        first_blood = next(record for record in index["records"] if record["title"] == "First Blood")
        self.assertIn("treatment has angered Rambo", first_blood["metadata"])
        self.assertEqual(index["movies_by_actor"]["sylvester stallone"], ["First Blood"])
        self.assertEqual(index["by_genre"]["action"], ["First Blood"])

    def test_first_parseable_nfo_wins_regardless_of_root_tag(self):
        folder = self.movie_dir("Candidates", "movie.mkv", "plain text release notes")
        (folder / "b-malformed.nfo").write_text("<movie>", encoding="utf-8")
        (folder / "c-other-root.nfo").write_text(
            "<document><title>Historical Semantics</title></document>", encoding="utf-8")
        (folder / "d-movie.nfo").write_text(
            "<movie><title>Should Not Win</title></movie>", encoding="utf-8")

        index = nfosearch2.build_index([self.root])

        self.assertEqual([record["title"] for record in index["records"]],
                         ["Historical Semantics"])
        self.assertEqual(nfosearch2.nfo_for_folder(folder).name, "c-other-root.nfo")
        self.assertEqual(index["lost_found"], [])

    def test_lost_found_resolution_is_enumerated_and_refreshable(self):
        folder = self.movie_dir("Mystery", "movie.mkv")
        nfosearch2.db = nfosearch2.build_index([self.root])
        self.assertTrue(nfosearch2.findLostFoundMovie("Mystery").endswith("movie.mkv"))
        self.assertIsNone(nfosearch2.findLostFoundMovie(str(folder)))
        self.assertIsNone(nfosearch2.findLostFoundMovie("../Mystery"))

        nfo = folder / "Mystery.nfo"
        nfo.write_text("<movie><title>Mystery Film</title><genre>drama</genre></movie>", encoding="utf-8")
        nfosearch2.db = nfosearch2.build_index([self.root])
        self.assertEqual(nfosearch2.db["lost_found"], [])
        self.assertIn("mystery film", nfosearch2.db["by_title"])

        nfo.unlink()
        nfosearch2.db = nfosearch2.build_index([self.root])
        self.assertEqual([record["name"] for record in nfosearch2.db["lost_found"]], ["Mystery"])


if __name__ == "__main__":
    unittest.main()
