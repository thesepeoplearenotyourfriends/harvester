import importlib.util
import json
import sys
import tempfile
import threading
import types
import unittest
from pathlib import Path
from unittest import mock


def load_host_module():
    path = Path(__file__).parents[1] / "movies-ui.py"
    spec = importlib.util.spec_from_file_location("movies_ui_host_for_tests", path)
    module = importlib.util.module_from_spec(spec)
    with mock.patch("os.getuid", return_value=1000), mock.patch("os.geteuid", return_value=1000), \
            mock.patch.dict(sys.modules, {"severin": types.SimpleNamespace()}):
        spec.loader.exec_module(module)
    return module


host = load_host_module()


class LibraryIndexTransportTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        root = Path(self.temporary.name)
        self.movie_index = root / "movies" / "library-index.json"
        self.tv_index = root / "tv" / "library-index.json"
        self.movie_index.parent.mkdir()
        self.tv_index.parent.mkdir()
        self.paths = mock.patch.multiple(
            host, MOVIE_LIBRARY_INDEX=str(self.movie_index), TV_LIBRARY_INDEX=str(self.tv_index))
        self.paths.start()

    def tearDown(self):
        self.paths.stop()
        self.temporary.cleanup()

    def test_maintenance_publishes_indexes_without_bulk_bridge_payload(self):
        host.movie_nfo.db = {"by_genre": {"drama": ["Film"]}, "records": [], "lost_found": []}
        host.tv_nfo.db = {"all_genres": ["Comedy"], "by_genre": {"comedy": ["Show"]}}
        empty_report = {key: [] for key in (
            "nfos_added", "nfos_updated", "nfos_removed", "posters_added", "posters_updated",
            "posters_removed", "actor_images_added", "actor_images_updated", "actor_images_removed")}

        with mock.patch.object(host, "_maintain_world", side_effect=lambda *args: dict(empty_report)):
            result = host.maintenance_refresh({})

        self.assertEqual(json.loads(self.movie_index.read_text())["by_genre"], {"drama": ["Film"]})
        self.assertEqual(json.loads(self.tv_index.read_text())["by_genre"], {"Comedy": ["Show"]})
        self.assertTrue(result["worlds"]["movies"]["library_index_changed"])
        self.assertNotIn("library_index", result["worlds"]["movies"])
        self.assertNotIn("library_index", result["worlds"]["tv"])

    def test_large_index_uses_cache_while_control_response_stays_small(self):
        huge_text = "metadata " * 200_000
        host.movie_nfo.db = {
            "by_genre": {"drama": ["Huge Film"]},
            "records": [{"title": "Huge Film", "metadata": huge_text}],
            "lost_found": [],
        }

        with mock.patch.object(host.movie_nfo, "build_index", return_value=host.movie_nfo.db):
            response = host.movies_library({})

        self.assertLess(len(json.dumps(response)), 100)
        self.assertGreater(self.movie_index.stat().st_size, 1_000_000)
        self.assertEqual(json.loads(self.movie_index.read_text())["metadata"][0]["text"], huge_text)

    def test_explicit_refresh_rescans_lost_found_filesystem(self):
        library = Path(self.temporary.name) / "library"
        folder = library / "Mystery"
        folder.mkdir(parents=True)
        (folder / "movie.mkv").write_bytes(b"video")

        with mock.patch.object(host.movie_nfo, "DIRS", [library]):
            host.movie_nfo.db = host.movie_nfo.build_index(host.movie_nfo.DIRS)
            self.assertEqual(host.movie_nfo.db["lost_found"][0]["name"], "Mystery")
            (folder / "Mystery.nfo").write_text(
                "<movie><title>Found Film</title><genre>drama</genre></movie>", encoding="utf-8")

            response = host.movies_library({})

        cached = json.loads(self.movie_index.read_text())
        self.assertEqual(cached["lost_found"], [])
        self.assertEqual(cached["by_genre"], {"drama": ["Found Film"]})
        self.assertTrue(response["library_index_changed"])
        self.assertNotIn("library_index", response)

    def test_cold_initialization_creates_library_index(self):
        backend = types.SimpleNamespace(
            DIRS=["unused"],
            db={},
            build_index=lambda dirs: {"by_genre": {"action": ["Cold Film"]},
                                      "records": [], "lost_found": []},
        )
        ready = threading.Event()
        with mock.patch.multiple(host, movie_nfo=backend, movie_ready=ready, movie_index_error=None):
            host._initialize_backend("movies")

        self.assertTrue(ready.is_set())
        self.assertEqual(json.loads(self.movie_index.read_text())["by_genre"],
                         {"action": ["Cold Film"]})


if __name__ == "__main__":
    unittest.main()
