const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

const html = fs.readFileSync('index.html', 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const context = {
  console,
  AbortController,
  document: {
    head: {appendChild() {}},
    addEventListener() {},
    createElement() { return {style: {}, appendChild() {}, set textContent(value) { this._text = value; }}; },
  },
};
context.window = context;
context.window.addEventListener = () => {};
vm.createContext(context);
vm.runInContext(script, context);

context.build_search_index(
  {action: ['First Blood'], drama: ['Another Film']},
  ['Sylvester Stallone'],
  {
    metadata: [{title: 'First Blood', text: 'The treatment\n\thas   angered Rambo to the point of resistance.'}],
    lost_found: [{id: 'Frogs', name: 'Frogs', media: 'Attenborough.Frogs.mkv'}],
  },
);

assert.strictEqual(context.search_library('first')[0].name, 'First Blood');
assert.strictEqual(context.search_library('stallone')[0].type, 'actor');
const metadata = context.search_library('angered')[0];
assert.strictEqual(metadata.type, 'metadata');
assert.strictEqual(metadata.name, 'First Blood');
assert.strictEqual(metadata.excerpt.match, 'angered');
assert.strictEqual(context.search_library('treatment has angered')[0].type, 'metadata');
assert.strictEqual(context.search_library('attenborough')[0].type, 'lost-found');

vm.runInContext(`worldState.movies.libraryIndex = {lost_found: [
  {id: 'Frogs', name: 'Frogs', media: 'Attenborough.Frogs.mkv'},
  {id: 'Mystery', name: 'Mystery', media: 'movie.mkv'}
]}`, context);
context.current_genre_entries = context.entries_for_genre('lost & found');
assert.strictEqual(context.entries_for_search_query('attenborough').length, 1);
const restored = context.entries_for_search_query('');
assert.deepStrictEqual(Array.from(restored, entry => entry.name), ['Frogs', 'Mystery']);
assert.ok(restored.every(entry => entry.type === 'lost-found'));

(async () => {
  const indexes = {
    movies: {version: 2, genres: ['new'], by_genre: {new: ['Large Film']},
      metadata: [{title: 'Large Film', text: 'x'.repeat(2_000_000)}], lost_found: []},
    tv: {version: 2, genres: ['shows'], by_genre: {shows: ['Fresh Show']}, metadata: [], lost_found: []},
  };
  context.fetch = async url => ({ok: true, json: async () => indexes[url.includes('/tv/') ? 'tv' : 'movies']});
  vm.runInContext(`
    activeWorld = 'movies'; uiGeneration = 0;
    worldState.movies.loaded = true;
    worldState.movies.libraryIndex = {version: 2, genres: ['old'], by_genre: {old: ['Old Film']}, metadata: [], lost_found: []};
  `, context);

  await context.applyMaintenanceResult({changed: false, worlds: {
    movies: {library_index_changed: true}, tv: {library_index_changed: true}
  }});
  assert.strictEqual(vm.runInContext('worldState.movies.pendingLibraryIndex.metadata[0].text.length', context), 2_000_000);
  assert.strictEqual(vm.runInContext('worldState.tv.libraryIndexDirty', context), true);
  assert.strictEqual(vm.runInContext('worldState.movies.libraryIndex.genres[0]', context), 'old');

  context.document.getElementById = () => ({innerHTML: '', value: ''});
  vm.runInContext(`
    load_cache_manifest = async function () { return true; };
    load_actor_index = async function () { return {version: 1, actors: []}; };
    present_library_index = function (library, actors) {
      worldState[activeWorld].libraryIndex = library;
      worldState[activeWorld].actorIndex = (actors || []).slice();
      worldState[activeWorld].loaded = true;
      return true;
    };
    clear_lower_preview = function () {};
    updateWorldToggle = function () {};
    UI.closeModal = function () {};
    UI.closeDropdowns = function () {};
  `, context);
  await context.toggleWorld();
  assert.strictEqual(vm.runInContext('activeWorld', context), 'tv');
  assert.strictEqual(vm.runInContext('worldState.tv.libraryIndex.genres[0]', context), 'shows');
  assert.strictEqual(vm.runInContext('worldState.tv.libraryIndexDirty', context), false);
  assert.strictEqual(vm.runInContext('worldState.movies.libraryIndex.genres[0]', context), 'old');

  // An actor-only maintenance change in an inactive world must force both of
  // that world's cache files to be loaded when it is next activated.
  vm.runInContext(`
    activeWorld = 'movies';
    worldState.tv.libraryIndexDirty = false;
    worldState.tv.actorIndex = ['Stale Actor'];
  `, context);
  vm.runInContext("load_actor_index = async function () { return {version: 1, actors: ['Fresh Actor']}; };", context);
  await context.applyMaintenanceResult({changed: false, worlds: {
    tv: {library_index_changed: false, actor_index_changed: true}
  }});
  assert.strictEqual(vm.runInContext('worldState.tv.libraryIndexDirty', context), true);
  await context.toggleWorld();
  assert.strictEqual(vm.runInContext('activeWorld', context), 'tv');
  assert.deepStrictEqual(Array.from(vm.runInContext('worldState.tv.actorIndex', context)), ['Fresh Actor']);
  assert.strictEqual(vm.runInContext('worldState.tv.libraryIndexDirty', context), false);
  console.log('dynamic search and cache-file library refresh checks passed');
})().catch(error => { console.error(error); process.exitCode = 1; });
