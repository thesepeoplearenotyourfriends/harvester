#!/usr/bin/python3
"""Combined Movies and TV Severin host with explicitly separate backends."""

import ast
import base64
import contextlib
import hashlib
import io
import json
import mimetypes
import os
import pwd
import grp
import subprocess
import stat
import sys
import threading
from pathlib import Path
from urllib.parse import unquote_to_bytes, urlparse

PROJECT_DIR = os.path.dirname(os.path.realpath(__file__))
PACKAGE_ID = "com.moviesui.app"
TRACE_PREFIX = "[movies-ui severin trace]"

# ============================================================
# User-configurable paths
# ============================================================
MOVIES_LIBRARY_DIR = "/mnt/2tb/Movie"
TV_LIBRARY_DIR = "/mnt/2tb/TV"
PLAYER_COMMAND = "vlcshortcut"
OPERATOR_ACCOUNT = "operator"

CACHE_ROOT = os.path.join(PROJECT_DIR, ".cache")
MOVIES_CACHE_DIR = os.path.join(CACHE_ROOT, "movies")
TV_CACHE_DIR = os.path.join(CACHE_ROOT, "tv")


def trace(message):
    print(f"{TRACE_PREFIX} {message}", file=sys.stderr, flush=True)


def _safe_cache_directory(path, uid=None, gid=None):
    """Create one app-owned cache directory without accepting symlink nodes."""
    current = PROJECT_DIR
    for component in os.path.relpath(path, PROJECT_DIR).split(os.sep):
        current = os.path.join(current, component)
        if os.path.lexists(current) and os.path.islink(current):
            raise RuntimeError(f"refusing symlinked cache path: {current}")
        os.makedirs(current, mode=0o700, exist_ok=True)
        if uid is not None:
            os.chown(current, uid, gid, follow_symlinks=False)
            os.chmod(current, 0o700, follow_symlinks=False)


def _drop_root_to_operator():
    """Automatically make a root-shell launch continue as the operator user."""
    if os.getuid() != 0 and os.geteuid() != 0:
        return
    try:
        account = pwd.getpwnam(OPERATOR_ACCOUNT)
        grp.getgrgid(account.pw_gid)
        if account.pw_uid == 0 or account.pw_gid == 0:
            raise RuntimeError("operator account must not be root")
        for directory in (CACHE_ROOT, MOVIES_CACHE_DIR, TV_CACHE_DIR):
            _safe_cache_directory(directory, account.pw_uid, account.pw_gid)
        os.initgroups(account.pw_name, account.pw_gid)
        os.setgid(account.pw_gid)
        os.setuid(account.pw_uid)

        # UID/GID changes do not update identity-bearing environment values
        # inherited from the root shell.  Normalize only those values here;
        # graphical-session variables such as DISPLAY and XAUTHORITY remain
        # untouched.
        os.environ["HOME"] = account.pw_dir
        os.environ["USER"] = account.pw_name
        os.environ["LOGNAME"] = account.pw_name
        os.environ["SHELL"] = account.pw_shell

        operator_runtime = f"/run/user/{account.pw_uid}"
        try:
            runtime_stat = os.stat(operator_runtime, follow_symlinks=False)
            valid_operator_runtime = (
                stat.S_ISDIR(runtime_stat.st_mode)
                and runtime_stat.st_uid == account.pw_uid
            )
        except OSError:
            valid_operator_runtime = False

        inherited_runtime = os.environ.get("XDG_RUNTIME_DIR")
        inherited_runtime_valid = False
        if inherited_runtime:
            try:
                inherited_stat = os.stat(inherited_runtime, follow_symlinks=False)
                inherited_runtime_valid = (
                    stat.S_ISDIR(inherited_stat.st_mode)
                    and inherited_stat.st_uid == account.pw_uid
                    and os.access(inherited_runtime, os.R_OK | os.W_OK | os.X_OK)
                )
            except OSError:
                pass
        if not inherited_runtime_valid:
            if valid_operator_runtime:
                os.environ["XDG_RUNTIME_DIR"] = operator_runtime
            else:
                os.environ.pop("XDG_RUNTIME_DIR", None)

        root_bus = "/run/user/0/bus"
        inherited_bus = os.environ.get("DBUS_SESSION_BUS_ADDRESS", "")
        if root_bus in inherited_bus:
            operator_bus = os.path.join(operator_runtime, "bus")
            try:
                operator_bus_is_socket = stat.S_ISSOCK(os.stat(operator_bus).st_mode)
            except OSError:
                operator_bus_is_socket = False
            if valid_operator_runtime and operator_bus_is_socket:
                os.environ["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path={operator_bus}"
            else:
                os.environ.pop("DBUS_SESSION_BUS_ADDRESS", None)
    except (KeyError, OSError, RuntimeError) as exc:
        raise RuntimeError(f"fatal: could not drop root privileges to {OPERATOR_ACCOUNT}: {exc}") from exc
    if os.getuid() == 0 or os.geteuid() == 0:
        raise RuntimeError("fatal: privilege drop verification failed; refusing to launch Severin as root")


_drop_root_to_operator()
for _directory in (MOVIES_CACHE_DIR, TV_CACHE_DIR):
    _safe_cache_directory(_directory)
os.chdir(PROJECT_DIR)

# Severin and both metadata implementations are loaded only after privilege drop.
import severin

import nfosearch2 as movie_nfo
import tv_nfosearch2 as tv_nfo
movie_nfo.DIRS = [MOVIES_LIBRARY_DIR]
tv_nfo.DIRS = [TV_LIBRARY_DIR]

movie_lock = threading.Lock()
tv_lock = threading.Lock()
movie_cache_lock = threading.Lock()
tv_cache_lock = threading.Lock()
movie_ready = threading.Event()
tv_ready = threading.Event()
movie_index_error = None
tv_index_error = None

CACHE_VERSION = 1
ACTOR_INDEX_CACHE_VERSION = 1
MOVIE_MANIFEST = os.path.join(MOVIES_CACHE_DIR, "manifest.json")
TV_MANIFEST = os.path.join(TV_CACHE_DIR, "manifest.json")
MOVIE_ACTOR_INDEX = os.path.join(MOVIES_CACHE_DIR, "actor-index.json")
TV_ACTOR_INDEX = os.path.join(TV_CACHE_DIR, "actor-index.json")
MOVIE_INVENTORY = os.path.join(MOVIES_CACHE_DIR, "library-inventory.json")
TV_INVENTORY = os.path.join(TV_CACHE_DIR, "library-inventory.json")
MOVIE_LIBRARY_INDEX = os.path.join(MOVIES_CACHE_DIR, "library-index.json")
TV_LIBRARY_INDEX = os.path.join(TV_CACHE_DIR, "library-index.json")
INVENTORY_VERSION = 3
LIBRARY_INDEX_CACHE_VERSION = 2


def _empty_cache_manifest():
    return {"version": CACHE_VERSION, "titles": {}, "actors": {}}


def _read_cache_manifest(path):
    try:
        with open(path, encoding="utf-8") as source:
            manifest = json.load(source)
        if (manifest.get("version") != CACHE_VERSION or
                not isinstance(manifest.get("titles"), dict) or
                not isinstance(manifest.get("actors"), dict)):
            return _empty_cache_manifest()
        return manifest
    except (FileNotFoundError, OSError, ValueError, TypeError):
        return _empty_cache_manifest()


def _cache_key(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _cached_image_path(kind, name, mime_type):
    extension = mimetypes.guess_extension(mime_type or "") or ".img"
    return f"{kind}/{_cache_key(name)}{extension}"


def _cache_image(cache_dir, manifest_path, lock, kind, name, image_bytes, mime_type):
    if image_bytes is None:
        return
    relative = _cached_image_path(kind, name, mime_type)
    destination = os.path.join(cache_dir, relative)
    with lock:
        try:
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            temporary = f"{destination}.tmp-{os.getpid()}-{threading.get_ident()}"
            with open(temporary, "wb") as output:
                output.write(image_bytes)
            os.replace(temporary, destination)
            manifest = _read_cache_manifest(manifest_path)
            section = "titles" if kind == "posters" else "actors"
            manifest[section].setdefault(name, {})["image"] = relative
            _atomic_write_text(manifest_path, json.dumps(manifest, ensure_ascii=False, separators=(",", ":")))
        except OSError as exc:
            trace(f"cache image write skipped: {exc}")


def _cache_plot(manifest_path, lock, title, plot):
    with lock:
        try:
            manifest = _read_cache_manifest(manifest_path)
            manifest["titles"].setdefault(title, {})["plot"] = plot
            _atomic_write_text(manifest_path, json.dumps(manifest, ensure_ascii=False, separators=(",", ":")))
        except OSError as exc:
            trace(f"cache plot write skipped: {exc}")


def _cache_actor_index(path, actors):
    try:
        _atomic_write_text(path, json.dumps({"version": ACTOR_INDEX_CACHE_VERSION, "actors": actors}, ensure_ascii=False))
    except OSError as exc:
        trace(f"actor index cache write skipped: {exc}")


def _read_json_cache(path, validator):
    try:
        with open(path, encoding="utf-8") as source:
            value = json.load(source)
        return value if validator(value) else None
    except (OSError, ValueError, TypeError):
        return None


def _file_metadata(path, root, include_path=True):
    if path is None:
        return None
    try:
        metadata = os.stat(path, follow_symlinks=False)
    except OSError:
        return None
    result = {"size": metadata.st_size, "mtime_ns": metadata.st_mtime_ns,
              "ctime_ns": metadata.st_ctime_ns}
    if include_path:
        result["path"] = os.path.relpath(path, root)
    return result


def _actor_image_entries(library_root, extensions):
    """Scan .actors once and return deterministic source entries."""
    root = os.path.realpath(library_root)
    actor_dir = os.path.join(root, ".actors")
    entries = []
    try:
        names = sorted(os.listdir(actor_dir), key=str.casefold)
    except OSError:
        return entries
    for filename in names:
        path = os.path.join(actor_dir, filename)
        if os.path.splitext(filename)[1].casefold() not in extensions or not os.path.isfile(path):
            continue
        metadata = _file_metadata(path, root)
        if metadata:
            entries.append((filename, path, metadata))
    return entries


def _actor_source(actor, entries, tv=False):
    wanted = (tv_nfo.safe_actor_stem(actor) if tv else actor.replace(" ", "_")).casefold()
    fallback = None
    for filename, path, metadata in entries:
        stem = os.path.splitext(filename)[0].casefold()
        if tv and stem == wanted:
            return metadata
        if wanted in filename.casefold() and fallback is None:
            fallback = metadata
    return fallback


def _inventory(library_root, backend, name, manifest):
    """Build a version-2 inventory whose unit is one media directory."""
    root = os.path.realpath(library_root)
    records = {}
    for record in backend.db.get("records", []):
        folder = record.get("folder")
        if not folder:
            continue
        relative = os.path.relpath(folder, root)
        cache_title = record.get("display_title") if name == "tv" else record.get("title")
        nfo = backend.nfo_for_folder(Path(folder))
        poster = backend.poster_for_folder(Path(folder))
        records[relative] = {"cache_title": cache_title or os.path.basename(folder),
                             "nfo": _file_metadata(str(nfo), root) if nfo else None,
                             "poster": _file_metadata(str(poster), root) if poster else None}
    if name == "movies":
        for record in backend.db.get("lost_found", []):
            folder = record.get("folder")
            if not folder:
                continue
            relative = os.path.relpath(folder, root)
            nfo = backend.nfo_for_folder(Path(folder))
            video = backend._first_video(folder)
            records[relative] = {"cache_title": record.get("name") or os.path.basename(folder),
                                 "nfo": _file_metadata(str(nfo), root) if nfo else None,
                                 "poster": None,
                                 "video": _file_metadata(video, root) if video else None,
                                 "lost_found": True}
    entries = _actor_image_entries(root, backend.IMAGE_EXTENSIONS)
    actor_files = {metadata["path"]: {key: value for key, value in metadata.items() if key != "path"}
                   for _, _, metadata in entries}
    cached_sources = {}
    for actor in manifest.get("actors", {}):
        source = _actor_source(actor, entries, tv=name == "tv")
        if source:
            cached_sources[actor] = source
    return {"version": INVENTORY_VERSION, "records": records,
            "actor_files": actor_files, "cached_actor_sources": cached_sources}


def _delete_derivative(cache_dir, entry):
    if not isinstance(entry, dict) or not isinstance(entry.get("image"), str):
        return
    try:
        os.remove(os.path.join(cache_dir, entry["image"]))
    except OSError:
        pass


def _invalidate_manifest(manifest_path, cache_dir, lock, plots, posters, titles, actors):
    """Apply exact semantic invalidations in one manifest replacement."""
    if not any((plots, posters, titles, actors)):
        return
    with lock:
        manifest = _read_cache_manifest(manifest_path)
        for title in titles:
            _delete_derivative(cache_dir, manifest["titles"].get(title))
            manifest["titles"].pop(title, None)
        for title in plots:
            entry = manifest["titles"].get(title)
            if isinstance(entry, dict):
                entry.pop("plot", None)
        for title in posters:
            entry = manifest["titles"].get(title)
            if isinstance(entry, dict):
                _delete_derivative(cache_dir, entry)
                entry.pop("image", None)
        for actor in actors:
            _delete_derivative(cache_dir, manifest["actors"].get(actor))
            manifest["actors"].pop(actor, None)
        _atomic_write_text(manifest_path, json.dumps(manifest, ensure_ascii=False, separators=(",", ":")))


def _raw_actor_name(path, actors, source_path_to_actor, tv):
    mapped_actor = source_path_to_actor.get(path)
    if mapped_actor:
        return mapped_actor
    filename = os.path.basename(path).casefold()
    for actor in actors:
        wanted = (tv_nfo.safe_actor_stem(actor) if tv else actor.replace(" ", "_")).casefold()
        if wanted in filename:
            return actor
    return os.path.splitext(os.path.basename(path))[0].replace("_", " ")


def _invalid_cached_actors(manifest, old, current):
    """Find stale derivatives, including actors cached after the prior inventory."""
    invalid = set()
    for actor in manifest["actors"]:
        current_source = current["cached_actor_sources"].get(actor)
        old_source = old["cached_actor_sources"].get(actor)
        if old_source is not None:
            source_changed = current_source != old_source
        elif current_source is None:
            source_changed = True
        else:
            source_path = current_source["path"]
            current_metadata = {key: value for key, value in current_source.items() if key != "path"}
            source_changed = old["actor_files"].get(source_path) != current_metadata
        if source_changed:
            invalid.add(actor)
    return invalid


def _maintain_world(name, library, inventory_path, actor_index_path, manifest_path, cache_dir,
                    backend, backend_lock, cache_lock):
    replacement = backend.build_index(backend.DIRS)
    with backend_lock:
        backend.db = replacement
    manifest = _read_cache_manifest(manifest_path)
    current = _inventory(library, backend, name, manifest)
    old = _read_json_cache(inventory_path, lambda value: isinstance(value, dict) and
                           value.get("version") == INVENTORY_VERSION and
                           isinstance(value.get("records"), dict) and
                           isinstance(value.get("actor_files"), dict) and
                           isinstance(value.get("cached_actor_sources"), dict))
    report = {key: [] for key in ("nfos_added", "nfos_updated", "nfos_removed",
              "posters_added", "posters_updated", "posters_removed",
              "actor_images_added", "actor_images_updated", "actor_images_removed",
              "plots_invalidated", "posters_invalidated", "title_entries_invalidated",
              "actor_images_invalidated")}
    actors = list(backend.db.get("all_actors", []))
    if old is None:
        _atomic_write_text(actor_index_path, json.dumps({"version": ACTOR_INDEX_CACHE_VERSION, "actors": actors}, ensure_ascii=False))
        report["actor_index_changed"] = True
        _atomic_write_text(inventory_path, json.dumps(current, ensure_ascii=False, separators=(",", ":")))
        return report

    before, after = old["records"], current["records"]
    added, removed, common = set(after) - set(before), set(before) - set(after), set(after) & set(before)
    nfo_changed = {key for key in common if before[key].get("nfo") != after[key].get("nfo")}
    poster_changed = {key for key in common if before[key].get("poster") != after[key].get("poster")}

    plots, posters, titles = set(), set(), set()
    for key in removed:
        titles.add(before[key]["cache_title"])
        report["nfos_removed"].append(before[key]["cache_title"])
        if before[key].get("poster"): report["posters_removed"].append(before[key]["cache_title"])
    for key in added:
        title = after[key]["cache_title"]
        titles.add(title)  # defensive conflict removal
        report["nfos_added"].append(title)
        if after[key].get("poster"): report["posters_added"].append(title)
    for key in nfo_changed:
        old_title, new_title = before[key]["cache_title"], after[key]["cache_title"]
        report["nfos_updated"].append(new_title)
        if old_title != new_title:
            titles.update((old_title, new_title))
        else:
            plots.add(new_title)
    for key in poster_changed:
        title = after[key]["cache_title"]
        posters.add(title)
        prior, latest = before[key].get("poster"), after[key].get("poster")
        report["posters_added" if not prior else "posters_removed" if not latest else "posters_updated"].append(title)

    old_files, new_files = old["actor_files"], current["actor_files"]
    file_added, file_removed = set(new_files) - set(old_files), set(old_files) - set(new_files)
    file_updated = {path for path in set(old_files) & set(new_files) if old_files[path] != new_files[path]}
    invalid_actors = _invalid_cached_actors(manifest, old, current)
    source_path_to_actor = {
        source["path"]: actor
        for sources in (old["cached_actor_sources"], current["cached_actor_sources"])
        for actor, source in sources.items()
        if isinstance(source, dict) and isinstance(source.get("path"), str)
    }
    for key, paths in (("actor_images_added", file_added), ("actor_images_removed", file_removed),
                       ("actor_images_updated", file_updated)):
        report[key] = sorted((_raw_actor_name(path, actors, source_path_to_actor, name == "tv")
                              for path in paths), key=str.casefold)

    metadata_changed = bool(added or removed or nfo_changed)
    if metadata_changed:
        _atomic_write_text(actor_index_path, json.dumps({"version": ACTOR_INDEX_CACHE_VERSION, "actors": actors}, ensure_ascii=False))
        report["actor_index_changed"] = True
    report["plots_invalidated"] = sorted(plots, key=str.casefold)
    report["posters_invalidated"] = sorted(posters, key=str.casefold)
    report["title_entries_invalidated"] = sorted(titles, key=str.casefold)
    report["actor_images_invalidated"] = sorted(invalid_actors, key=str.casefold)
    _invalidate_manifest(manifest_path, cache_dir, cache_lock, plots, posters, titles, invalid_actors)

    if current != old:
        _atomic_write_text(inventory_path, json.dumps(current, ensure_ascii=False, separators=(",", ":")))
    for key in report:
        if isinstance(report[key], list): report[key] = sorted(set(report[key]), key=str.casefold)
    return report

def _warm_cache(target, *args):
    threading.Thread(target=target, args=args, daemon=True, name="movies-ui-cache-write").start()


def _format_result(result):
    if result is None: return "None"
    if isinstance(result, set): result = sorted(result)
    return str(result)


def _movie_call(function, *args):
    stdout = io.StringIO()
    with movie_lock, contextlib.redirect_stdout(stdout):
        result = function(*args)
    return stdout.getvalue().strip() or _format_result(result)


def _tv_call(function, *args):
    stdout = io.StringIO()
    with tv_lock, contextlib.redirect_stdout(stdout):
        result = function(*args)
    return stdout.getvalue().strip() or _format_result(result)


BRIDGE_ACTIONS = {}
def bridge_action(action):
    def register(function):
        BRIDGE_ACTIONS[action] = function
        return function
    return register

@bridge_action("__ping__")
def bridge_ping(data):
    return {"pong": True, "echo": data}


def _image_payload_to_bytes(payload):
    if not payload or payload == "None": return None, None
    payload = payload.strip()
    if payload.startswith("data:"):
        header, encoded = payload.split(",", 1)
        mime = header[5:].split(";", 1)[0] or "application/octet-stream"
        return (base64.b64decode(encoded) if ";base64" in header else unquote_to_bytes(encoded)), mime
    path = urlparse(payload).path if payload.startswith("file://") else payload
    if os.path.isfile(path):
        with open(path, "rb") as source: return source.read(), mimetypes.guess_type(path)[0] or "application/octet-stream"
    raise ValueError("image payload was not a data URI or readable file")


def _image_bytes_to_data_url(value, mime):
    return f"data:{mime};base64,{base64.b64encode(value).decode('ascii')}" if value is not None else None


def _json_safe(value):
    if isinstance(value, set): return sorted(_json_safe(item) for item in value)
    if isinstance(value, dict): return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)): return [_json_safe(item) for item in value]
    return value


def _required_text(data, field, action):
    value = data.get(field) if isinstance(data, dict) else None
    if not isinstance(value, str) or not value.strip(): raise ValueError(f"{action} requires a non-empty {field}")
    return value.strip()


def _parse_list(value):
    if value is None or value == "None": return []
    if isinstance(value, (set, list, tuple)): return sorted(value) if isinstance(value, set) else list(value)
    if isinstance(value, str):
        try: parsed = ast.literal_eval(value.strip())
        except (SyntaxError, ValueError): parsed = None
        if isinstance(parsed, (set, list, tuple)): return sorted(parsed) if isinstance(parsed, set) else list(parsed)
        return [line for line in value.splitlines() if line.strip()]
    return [value]


def _image_result(world, kind, name, payload):
    image_bytes, mime = _image_payload_to_bytes(payload)
    data_url = _image_bytes_to_data_url(image_bytes, mime)
    if data_url is None: return {"available": False}
    cache_dir, manifest, lock = ((MOVIES_CACHE_DIR, MOVIE_MANIFEST, movie_cache_lock) if world == "movies" else (TV_CACHE_DIR, TV_MANIFEST, tv_cache_lock))
    _warm_cache(_cache_image, cache_dir, manifest, lock, kind, name, image_bytes, mime)
    return {"available": True, "image_uri": data_url, "cache_uri": _cached_image_path(kind, name, mime)}


def _library_index_snapshot(world, backend):
    """Return the small, disposable presentation index used for warm startup."""
    if world == "movies":
        by_genre = _json_safe(backend.db.get("by_genre", {}))
        genres = sorted(by_genre)
    else:
        genres = list(backend.db.get("all_genres", []))
        by_genre = {
            genre: list(backend.db.get("by_genre", {}).get(backend.norm_text(genre), []))
            for genre in genres
        }
        genres = sorted(genres, key=str.casefold)
    snapshot = {
        "version": LIBRARY_INDEX_CACHE_VERSION,
        "genres": genres,
        "by_genre": by_genre,
    }
    if world == "movies":
        snapshot["metadata"] = [
            {"title": record["title"], "text": record.get("metadata", record.get("plot", ""))}
            for record in backend.db.get("records", [])
        ]
        snapshot["lost_found"] = [
            {key: record[key] for key in ("id", "name", "media")}
            for record in backend.db.get("lost_found", [])
        ]
    else:
        snapshot["metadata"] = []
        snapshot["lost_found"] = []
    return snapshot


def _write_library_index(path, snapshot):
    try:
        _atomic_write_text(path, json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")))
    except OSError as exc:
        trace(f"library index cache write skipped: {exc}")


def _refresh_library_index_cache(world, backend, lock):
    """Atomically publish the current bulk index and report whether it changed."""
    path = MOVIE_LIBRARY_INDEX if world == "movies" else TV_LIBRARY_INDEX
    with lock:
        snapshot = _library_index_snapshot(world, backend)
    previous = _read_json_cache(path, lambda value: isinstance(value, dict))
    _write_library_index(path, snapshot)
    return previous != snapshot


def _rescan_library_index_cache(world, backend, lock):
    """Rebuild one backend from disk and publish its disposable indexes."""
    library_path = MOVIE_LIBRARY_INDEX if world == "movies" else TV_LIBRARY_INDEX
    actor_path = MOVIE_ACTOR_INDEX if world == "movies" else TV_ACTOR_INDEX
    replacement = backend.build_index(backend.DIRS)
    with lock:
        backend.db = replacement
        snapshot = _library_index_snapshot(world, backend)
        actors = list(backend.db.get("all_actors", []))
        previous_library = _read_json_cache(library_path, lambda value: isinstance(value, dict))
        previous_actors = _read_json_cache(
            actor_path,
            lambda value: isinstance(value, dict)
            and value.get("version") == ACTOR_INDEX_CACHE_VERSION
            and isinstance(value.get("actors"), list),
        )
        actor_snapshot = {"version": ACTOR_INDEX_CACHE_VERSION, "actors": actors}
        _write_library_index(library_path, snapshot)
        if previous_actors != actor_snapshot:
            _cache_actor_index(actor_path, actors)
    return {
        "library_index_changed": previous_library != snapshot,
        "actor_index_changed": previous_actors != actor_snapshot,
    }


@bridge_action("maintenance.refresh")
def maintenance_refresh(data):
    """Validate and maintain both independent worlds in one deferred request."""
    worlds = {
        "movies": _maintain_world("movies", MOVIES_LIBRARY_DIR, MOVIE_INVENTORY, MOVIE_ACTOR_INDEX,
                                  MOVIE_MANIFEST, MOVIES_CACHE_DIR, movie_nfo, movie_lock, movie_cache_lock),
        "tv": _maintain_world("tv", TV_LIBRARY_DIR, TV_INVENTORY, TV_ACTOR_INDEX,
                              TV_MANIFEST, TV_CACHE_DIR, tv_nfo, tv_lock, tv_cache_lock),
    }
    worlds["movies"]["library_index_changed"] = _refresh_library_index_cache(
        "movies", movie_nfo, movie_lock)
    worlds["tv"]["library_index_changed"] = _refresh_library_index_cache(
        "tv", tv_nfo, tv_lock)
    changed = any(any(report.get(key) for key in (
        "nfos_added", "nfos_updated", "nfos_removed", "posters_added",
        "posters_updated", "posters_removed", "actor_images_added",
        "actor_images_updated", "actor_images_removed")) for report in worlds.values())
    return {"changed": changed, "worlds": worlds}


def _initialize_backend(world):
    """Build a world index off-lock, then install it as one complete value."""
    global movie_index_error, tv_index_error
    backend, lock, ready = ((movie_nfo, movie_lock, movie_ready) if world == "movies"
                            else (tv_nfo, tv_lock, tv_ready))
    try:
        replacement = backend.build_index(backend.DIRS)
        with lock:
            backend.db = replacement
            snapshot = _library_index_snapshot(world, backend)
        index_path = MOVIE_LIBRARY_INDEX if world == "movies" else TV_LIBRARY_INDEX
        _write_library_index(index_path, snapshot)
    except Exception as exc:
        if world == "movies":
            movie_index_error = exc
        else:
            tv_index_error = exc
        trace(f"{world} index initialization failed: {exc}")
    finally:
        ready.set()


def _wait_for_backend(world):
    ready = movie_ready if world == "movies" else tv_ready
    ready.wait()
    error = movie_index_error if world == "movies" else tv_index_error
    if error is not None:
        raise RuntimeError(f"{world} library initialization failed: {error}") from error

# Movies backend: production helper, lock, indexes, cache, and playback semantics.
@bridge_action("movies.ensure_library_index_cache")
def movies_library(data):
    return _rescan_library_index_cache("movies", movie_nfo, movie_lock)

@bridge_action("movies.get_plot")
def movies_plot(data):
    title = _required_text(data, "title", "movies.get_plot")
    plot = _movie_call(movie_nfo.findPlotByTitle, movie_nfo.DIRS, title).strip(chr(39)).replace("None", "")
    _warm_cache(_cache_plot, MOVIE_MANIFEST, movie_cache_lock, title, plot)
    return {"title": title, "plot": plot}

@bridge_action("movies.get_poster")
def movies_poster(data):
    title = _required_text(data, "title", "movies.get_poster")
    result = _image_result("movies", "posters", title, _movie_call(movie_nfo.findPosterByTitle, title, movie_nfo.DIRS))
    return {"title": title, "poster_uri": result.pop("image_uri", None), **result}

@bridge_action("movies.get_cast")
def movies_cast(data):
    title = _required_text(data, "title", "movies.get_cast")
    return {"title": title, "actors": _parse_list(_movie_call(movie_nfo.findActorsForOneMovie, movie_nfo.DIRS, title))}

@bridge_action("movies.get_actor_index")
def movies_actors(data):
    actors = _parse_list(_movie_call(movie_nfo.findActors, movie_nfo.DIRS)); _warm_cache(_cache_actor_index, MOVIE_ACTOR_INDEX, actors)
    return {"actors": actors}

@bridge_action("movies.get_actor_image")
def movies_actor_image(data):
    name = _required_text(data, "name", "movies.get_actor_image")
    result = _image_result("movies", "actors", name, _movie_call(movie_nfo.findActorImage, name))
    return {"name": name, "actor_image_uri": result.pop("image_uri", None), **result}

@bridge_action("movies.get_titles_for_actor")
def movies_titles_for_actor(data):
    name = _required_text(data, "name", "movies.get_titles_for_actor")
    return {"name": name, "titles": _parse_list(_movie_call(movie_nfo.findMoviesByActor, name, movie_nfo.DIRS))}

@bridge_action("movies.play")
def movies_play(data):
    if isinstance(data, dict) and data.get("lost_found_id") is not None:
        identity = _required_text(data, "lost_found_id", "movies.play")
        with movie_lock: movie_file = movie_nfo.findLostFoundMovie(identity)
        result = {"lost_found_id": identity}
    else:
        title = _required_text(data, "title", "movies.play")
        with movie_lock: movie_file = movie_nfo.findMovieFileByTitle(movie_nfo.DIRS, title)
        result = {"title": title}
    if not movie_file or movie_file == "None": return {**result, "success": False, "error": "movie file not found"}
    subprocess.Popen([PLAYER_COMMAND, os.path.dirname(movie_file)], env={**os.environ, "QT_QPA_PLATFORMTHEME": "qt5ct"})
    return {**result, "success": True}

# TV backend: separate helper, lock, indexes, cache, and season-folder playback.
@bridge_action("tv.ensure_library_index_cache")
def tv_library(data):
    return _rescan_library_index_cache("tv", tv_nfo, tv_lock)

@bridge_action("tv.get_plot")
def tv_plot(data):
    title = _required_text(data, "title", "tv.get_plot")
    plot = _tv_call(tv_nfo.find_plot_by_title, tv_nfo.DIRS, title).strip(chr(39)).replace("None", "")
    _warm_cache(_cache_plot, TV_MANIFEST, tv_cache_lock, title, plot)
    return {"title": title, "plot": plot}

@bridge_action("tv.get_poster")
def tv_poster(data):
    title = _required_text(data, "title", "tv.get_poster")
    result = _image_result("tv", "posters", title, _tv_call(tv_nfo.find_poster_by_title, title, tv_nfo.DIRS))
    return {"title": title, "poster_uri": result.pop("image_uri", None), **result}

@bridge_action("tv.get_cast")
def tv_cast(data):
    title = _required_text(data, "title", "tv.get_cast")
    return {"title": title, "actors": _parse_list(_tv_call(tv_nfo.find_actors_for_season, tv_nfo.DIRS, title))}

@bridge_action("tv.get_actor_index")
def tv_actors(data):
    actors = _parse_list(_tv_call(tv_nfo.find_actors, tv_nfo.DIRS)); _warm_cache(_cache_actor_index, TV_ACTOR_INDEX, actors)
    return {"actors": actors}

@bridge_action("tv.get_actor_image")
def tv_actor_image(data):
    name = _required_text(data, "name", "tv.get_actor_image")
    result = _image_result("tv", "actors", name, _tv_call(tv_nfo.find_actor_image, name))
    return {"name": name, "actor_image_uri": result.pop("image_uri", None), **result}

@bridge_action("tv.get_titles_for_actor")
def tv_titles_for_actor(data):
    name = _required_text(data, "name", "tv.get_titles_for_actor")
    return {"name": name, "titles": _parse_list(_tv_call(tv_nfo.find_seasons_by_actor, name, tv_nfo.DIRS))}

@bridge_action("tv.play")
def tv_play(data):
    title = _required_text(data, "title", "tv.play")
    with tv_lock: season_folder = tv_nfo.find_season_folder_by_title(tv_nfo.DIRS, title)
    if not season_folder: return {"title": title, "success": False, "error": "season folder not found"}
    subprocess.Popen([PLAYER_COMMAND, season_folder], env={**os.environ, "QT_QPA_PLATFORMTHEME": "qt5ct"})
    return {"title": title, "success": True}

def _atomic_write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = f'{path}.tmp-{os.getpid()}'
    with open(temporary, 'w', encoding='utf-8', newline='') as output:
        output.write(text)
    os.replace(temporary, path)


def _decode_page_message(json_text):
    if not isinstance(json_text, str):
        raise ValueError('Severin bridge frame was not JSON text')
    message = json.loads(json_text)
    if isinstance(message, str):
        message = json.loads(message)
    if not isinstance(message, dict):
        raise ValueError('bridge message must be a JSON object')
    if 'id' not in message or 'action' not in message:
        raise ValueError('bridge message requires id and action')
    return message


def _make_reply(message_id, ok=True, result=None, error=None):
    response = {'id': message_id, 'ok': bool(ok)}
    if ok:
        response['result'] = _json_safe(result)
    else:
        response['error'] = str(error)
    return json.dumps(response, ensure_ascii=False, separators=(',', ':'))


def _run_bridge_job(app, receipt, json_text):
    """Deferred worker: execute one Movies/TV UI request, then route its reply.

    The current headed Severin controller owns its GUI/event loop inside
    app.run().  The bridge callback returns None to retain the receipt; this
    worker may finish later and app.write() enqueues the JSON response through
    the controller's dedicated writer path.
    """
    message_id = None
    action = None
    try:
        message = _decode_page_message(json_text)
        message_id = message['id']
        action = message['action']
        trace(f'job begin id={message_id!r} action={action!r} request_chars={len(json_text)}')
        data = message.get('data', {})
        handler = BRIDGE_ACTIONS.get(action)
        if handler is None:
            raise ValueError(f'unknown bridge action: {action}')
        if action == "maintenance.refresh":
            _wait_for_backend("movies")
            _wait_for_backend("tv")
        elif action.startswith("movies."):
            _wait_for_backend("movies")
        elif action.startswith("tv."):
            _wait_for_backend("tv")
        reply_json = _make_reply(message_id, ok=True, result=handler(data))
        trace(f'job ready id={message_id!r} action={action!r} reply_chars={len(reply_json)}')
    except Exception as exc:
        print(f'movies Severin bridge request failed: {exc}', file=sys.stderr)
        reply_json = _make_reply(message_id, ok=False, error=exc)

    try:
        app.write(receipt, reply_json)
        trace(f'job write returned id={message_id!r} action={action!r}')
    except Exception as exc:
        trace(f'job write failed id={message_id!r} action={action!r} type={type(exc).__name__} error={exc}')


def make_bridge_callback(app_box):
    """Adapt the current callback controller to Movies UI's async semantics.

    Returning None is deliberate: it retains the opaque receipt so the worker
    can reply by app.write() after NFO lookup, poster conversion, or VLC work.
    No pump(), read(), queue-drain loop, or GUI ownership exists here.
    """
    def bridge(receipt, json_text):
        trace(f'callback receipt={receipt!r} frame_chars={len(json_text)}')
        app = app_box.get('app')
        if app is None:
            print('movies Severin bridge arrived before App was installed', file=sys.stderr)
            return _make_reply(None, ok=False, error='Movies Severin host is not ready')

        threading.Thread(
            target=_run_bridge_job,
            args=(app, receipt, json_text),
            daemon=True,
            name='movies-ui-bridge-job',
        ).start()
        return None

    return bridge


def main():
    entry_path = os.path.join(PROJECT_DIR, 'index.html')
    print(f'Movies UI Severin entry: {entry_path}')
    print('Movies UI uses the disposable Severin package cache in .cache/.')

    app_box = {}
    bridge = make_bridge_callback(app_box)
    app = severin.App(
        width=800,
        height=400,
        bridge=bridge,
        package_id=PACKAGE_ID,
    )
    app_box['app'] = app
    try:
        app.load_path(entry_path)
        threading.Thread(target=_initialize_backend, args=("movies",), daemon=True,
                         name="movies-ui-movies-index").start()
        threading.Thread(target=_initialize_backend, args=("tv",), daemon=True,
                         name="movies-ui-tv-index").start()
        # Current headed-controller model: this blocks while the Severin child
        # owns winit, input, paint, resize, and document execution.  Requests
        # arrive via bridge(); deferred workers use app.write().
        app.run()
    except KeyboardInterrupt:
        print('Movies UI Severin host interrupted.')
    finally:
        app_box['app'] = None
        app.close()


if __name__ == '__main__':
    main()
